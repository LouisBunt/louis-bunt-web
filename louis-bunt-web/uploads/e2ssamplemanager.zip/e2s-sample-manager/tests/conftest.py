"""Test-Fixtures: synthetische WAVs und Referenz-Libraries.

Die Referenz-Library wird mit dem ORIGINAL-Code von Oe2sSLE
(tests/reference/) erzeugt, damit unser Port byteidentisch dagegen
getestet werden kann.
"""

import os
import struct
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "reference"))

import e2s_sample_all as ref_e2s  # noqa: E402  (Original-Code)


def make_wav_bytes(
    frames: np.ndarray,
    freq: int = 44100,
    bits: int = 16,
    extra_chunks: bytes = b"",
) -> bytes:
    """Minimales PCM-WAV aus (frames, channels)-Array bauen."""
    channels = frames.shape[1]
    if bits == 16:
        payload = np.ascontiguousarray(frames, dtype="<i2").tobytes()
    elif bits == 8:
        payload = (frames.astype(np.int16) // 256 + 128).astype(np.uint8).tobytes()
    elif bits == 24:
        as32 = (frames.astype(np.int32) << 8).astype("<i4")
        b = as32.tobytes()
        payload = b"".join(b[i:i + 3] for i in range(0, len(b), 4))
    elif bits == 32:
        payload = (frames.astype(np.int32) << 16).astype("<i4").tobytes()
    else:
        raise ValueError(bits)
    block_align = channels * bits // 8
    fmt = struct.pack(
        "<HHIIHH", 1, channels, freq, freq * block_align, block_align, bits
    )
    body = (
        b"WAVE"
        + b"fmt " + struct.pack("<I", len(fmt)) + fmt
        + extra_chunks
        + b"data" + struct.pack("<I", len(payload)) + payload
        + (b"\x00" if len(payload) & 1 else b"")
    )
    return b"RIFF" + struct.pack("<I", len(body)) + body


def make_test_frames(num_frames: int = 1000, channels: int = 1) -> np.ndarray:
    t = np.arange(num_frames)
    wave = (np.sin(2 * np.pi * t / 100) * 12000).astype(np.int16)
    return np.tile(wave.reshape(-1, 1), (1, channels))


@pytest.fixture
def wav_file_mono(tmp_path):
    path = tmp_path / "test_mono.wav"
    path.write_bytes(make_wav_bytes(make_test_frames(1000, 1)))
    return str(path)


@pytest.fixture
def wav_file_stereo(tmp_path):
    path = tmp_path / "test_stereo.wav"
    path.write_bytes(make_wav_bytes(make_test_frames(1000, 2)))
    return str(path)


def make_reference_library(path: str, wav_paths: list[str], nums: list[int]) -> None:
    """e2sSample.all mit dem Original-Oe2sSLE-Code erzeugen."""
    all_file = ref_e2s.e2s_sample_all()
    for wav_path, num in zip(wav_paths, nums):
        with open(wav_path, "rb") as f:
            sample = ref_e2s.e2s_sample(f)
        korg_chunk = sample.RIFF.chunkList.get_chunk(b"korg")
        if not korg_chunk:
            import RIFF as ref_riff

            korg_data = ref_e2s.RIFF_korg()
            korg_chunk = ref_riff.Chunk(
                header=ref_riff.ChunkHeader(id=b"korg"), data=korg_data
            )
            sample.RIFF.chunkList.chunks.append(korg_chunk)
            sample.header.size += len(korg_chunk)
            esli = ref_e2s.RIFF_korg_esli()
            esli_chunk = ref_riff.Chunk(
                header=ref_riff.ChunkHeader(id=b"esli"), data=esli
            )
            korg_chunk.data.chunkList.chunks.append(esli_chunk)
            fmt = sample.get_fmt()
            data = sample.get_data()
            esli.OSC_name = os.path.basename(wav_path).encode()[:16]
            esli.samplingFreq = fmt.samplesPerSec
            esli.OSC_EndPoint_offset = esli.OSC_LoopStartPoint_offset = (
                len(data) - fmt.blockAlign
            )
            esli.WAV_dataSize = len(data)
            if fmt.blockAlign // fmt.channels != fmt.blockAlign:
                esli.useChan1 = True
            esli.playVolume = 65535
        sample.get_esli().set_OSCNum(num)
        all_file.samples.append(sample)
    all_file.save(path)


@pytest.fixture
def reference_library(tmp_path):
    wavs = []
    for i, (frames, chans) in enumerate([(800, 1), (1200, 2), (500, 1)]):
        p = tmp_path / f"ref{i}.wav"
        p.write_bytes(make_wav_bytes(make_test_frames(frames, chans)))
        wavs.append(str(p))
    lib_path = str(tmp_path / "e2sSample.all")
    make_reference_library(lib_path, wavs, [19, 25, 501])
    return lib_path
