"""GUI-Tests (offscreen): Model, Undo/Redo, Import, Batch, Backup."""

import os

import numpy as np
import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication

from e2s_manager.backup import backup_file
from e2s_manager.core import dsp
from e2s_manager.gui.main_window import MainWindow
from e2s_manager.gui.sample_model import (
    COL_CAT, COL_NAME, COL_NUM, COL_ONESHOT,
)

from conftest import make_test_frames, make_wav_bytes


@pytest.fixture(scope="session")
def app():
    application = QApplication.instance() or QApplication([])
    yield application


@pytest.fixture
def window(app, reference_library):
    win = MainWindow()
    win.action_open(path=reference_library)
    yield win
    win.doc.undo_stack.setClean()  # Schließen ohne Rückfrage
    win.close()


def test_open_populates_model(window):
    assert window.model.rowCount() == 3
    index = window.model.index(0, COL_NUM)
    assert window.model.data(index, Qt.DisplayRole) == 19


def test_rename_with_undo(window):
    model = window.model
    index = model.index(0, COL_NAME)
    old_name = model.data(index, Qt.DisplayRole)
    assert model.setData(index, "NeuerName", Qt.EditRole)
    assert model.data(index, Qt.DisplayRole) == "NeuerName"
    assert window.doc.dirty
    window.doc.undo_stack.undo()
    assert model.data(index, Qt.DisplayRole) == old_name


def test_set_category(window):
    model = window.model
    index = model.index(0, COL_CAT)
    assert model.setData(index, "Kick", Qt.EditRole)
    assert model.data(index, Qt.DisplayRole) == "Kick"


def test_oneshot_toggle_resets_loop(window):
    model = window.model
    sample = model.sample_at(0)
    esli = sample.esli
    # Loop einschalten und Loop-Punkt versetzen
    model.setData(model.index(0, COL_ONESHOT), Qt.Unchecked, Qt.CheckStateRole)
    esli.loop_start_offset = 0
    model.setData(model.index(0, COL_ONESHOT), Qt.Checked, Qt.CheckStateRole)
    assert esli.one_shot
    assert esli.loop_start_offset == esli.end_offset


def test_renumber_with_push(window):
    doc = window.doc
    samples = doc.library.samples
    # Sample #25 auf #19 schieben -> altes #19 muss auf #18? Nein: nach oben
    # geschoben wird ungültig (18 < 19), also darf der Plan nicht klappen
    plan = doc.plan_renumber(samples[1], 19)
    assert plan is None
    # nach unten: #19 -> #25, altes #25 rückt auf #26
    plan = doc.plan_renumber(samples[0], 25)
    assert plan is not None
    assert plan[samples[0]] == 25
    assert plan[samples[1]] == 26


def test_renumber_skips_forbidden_range(window):
    """Verschieben über die Lücke: Nachrücker landen bei 501, nicht 422.

    Samples liegen bei 19/25/501. #19 auf 421 schieben verhält sich wie
    im Original: die nachfolgenden werden weitergeschoben, wobei die
    verbotene Lücke 422-500 übersprungen wird.
    """
    doc = window.doc
    samples = doc.library.samples
    plan = doc.plan_renumber(samples[0], 421)
    assert plan is not None
    assert plan[samples[0]] == 421
    assert plan[samples[1]] == 501  # 422 ist verboten -> 501
    assert plan[samples[2]] == 502  # Konfliktkette


def test_import_wav_and_undo(window, tmp_path):
    wav = tmp_path / "neu.wav"
    wav.write_bytes(make_wav_bytes(make_test_frames(300, 1)))
    before = len(window.doc.library)
    window._import_paths([str(wav)])
    assert len(window.doc.library) == before + 1
    added = window.doc.library.get_by_num(20)  # 19 belegt -> 20
    assert added is not None
    assert added.esli.name == "neu"
    window.doc.undo_stack.undo()
    assert len(window.doc.library) == before


def test_import_multiple_gets_sequential_nums(window, tmp_path):
    paths = []
    for i in range(3):
        wav = tmp_path / f"multi{i}.wav"
        wav.write_bytes(make_wav_bytes(make_test_frames(100, 1)))
        paths.append(str(wav))
    window._import_paths(paths)
    nums = {s.esli.osc_num for s in window.doc.library}
    assert {20, 21, 22} <= nums


def test_delete_and_undo(window):
    doc = window.doc
    sample = doc.library.samples[0]
    window.table.selectRow(0)
    window.action_delete()
    assert sample not in doc.library.samples
    doc.undo_stack.undo()
    assert sample in doc.library.samples
    assert doc.library.samples[0] is sample  # wieder einsortiert


def test_batch_normalize_macro_undo(window):
    doc = window.doc
    samples = list(doc.library.samples)
    quiet = np.zeros((200, 1), dtype=np.int16)
    quiet[50:150] = 500
    dsp.set_frames(samples[0], quiet)
    raw_before = bytes(samples[0].data.rawdata)
    window._batch_transform(samples, dsp.normalize, "Normalisieren")
    assert bytes(samples[0].data.rawdata) != raw_before
    doc.undo_stack.undo()  # Macro = ein Undo-Schritt
    assert bytes(samples[0].data.rawdata) == raw_before


def test_batch_trim_silence(window):
    doc = window.doc
    sample = doc.library.samples[0]
    padded = np.zeros((2000, 1), dtype=np.int16)
    padded[900:1100] = 20000
    dsp.set_frames(sample, padded)
    window._batch_transform(
        [sample], lambda s: dsp.trim_silence(s, -60.0), "Auto-Trim"
    )
    assert len(dsp.get_frames(sample)) < 500
    doc.undo_stack.undo()
    assert len(dsp.get_frames(sample)) == 2000


def test_mono_conversion_command(window):
    doc = window.doc
    stereo = next(s for s in doc.library.samples if s.esli.is_stereo)
    window._convert_mono([stereo], 0.0)
    assert not stereo.esli.is_stereo
    assert stereo.fmt.channels == 1
    doc.undo_stack.undo()
    assert stereo.esli.is_stereo
    assert stereo.fmt.channels == 2


def test_filter_proxy_search(window):
    window.proxy.set_search("ref0")
    assert window.proxy.rowCount() == 1
    window.proxy.set_search("")
    assert window.proxy.rowCount() == 3


def test_filter_proxy_category(window):
    from e2s_manager.core.esli import OscCategory
    window.model.sample_at(0).esli.osc_category = OscCategory.KICK
    window.proxy.set_category(OscCategory.KICK)
    assert window.proxy.rowCount() == 1
    window.proxy.set_category(None)
    assert window.proxy.rowCount() == 3


def test_move_rows_via_drag_handler(window):
    doc = window.doc
    first = doc.library.samples[0]
    target_num = doc.library.samples[2].esli.osc_num
    window._move_rows([0], 2)
    assert first.esli.osc_num == target_num
    doc.undo_stack.undo()
    assert first.esli.osc_num == 19


def test_save_creates_backup(window, tmp_path):
    out = str(tmp_path / "with_backup.all")
    window.doc.save(out)
    assert backup_file(out) is not None
    backup_dir = out + ".backup"
    assert len(os.listdir(backup_dir)) == 1
    # Rotation: nur die letzten 2 behalten
    for _ in range(4):
        backup_file(out, keep=2)
    assert len(os.listdir(backup_dir)) == 2


def test_memory_bar_updates(window):
    used = window.doc.library.total_wav_size()
    assert str(len(window.doc.library)) in window.memory_label.text()
    assert window.memory_bar.value() >= 0
    assert used > 0
