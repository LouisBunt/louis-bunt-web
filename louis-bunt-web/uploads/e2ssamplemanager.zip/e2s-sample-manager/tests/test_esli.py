"""esli-Chunk: Feld-Offsets und Defaults gegen das Original prüfen."""

from e2s_manager.core.esli import Esli, ESLI_SIZE, sanitize_name

import e2s_sample_all as ref_e2s  # Original aus tests/reference/


def test_default_esli_matches_original():
    ours = Esli()
    theirs = ref_e2s.RIFF_korg_esli()
    assert bytes(ours.rawdata) == bytes(theirs.rawdata)
    assert len(ours.rawdata) == ESLI_SIZE


def test_field_writes_match_original():
    ours = Esli()
    theirs = ref_e2s.RIFF_korg_esli()

    ours.osc_num = 42
    theirs.set_OSCNum(42)
    ours.name = "Test Sample"
    theirs.OSC_name = b"Test Sample"
    for obj_set in ((ours, "osc_category", 5), (ours, "play_volume", 65535),
                    (ours, "sampling_freq", 48000), (ours, "sample_tune", -12),
                    (ours, "start_point_address", 100),
                    (ours, "loop_start_offset", 200),
                    (ours, "end_offset", 300),
                    (ours, "wav_data_size", 4000),
                    (ours, "play_log_period", 30000)):
        setattr(*obj_set)
    theirs.OSC_category = 5
    theirs.playVolume = 65535
    theirs.samplingFreq = 48000
    theirs.sampleTune = -12
    theirs.OSC_StartPoint_address = 100
    theirs.OSC_LoopStartPoint_offset = 200
    theirs.OSC_EndPoint_offset = 300
    theirs.WAV_dataSize = 4000
    theirs.playLogPeriod = 30000
    ours.one_shot = False
    theirs.OSC_OneShot = False
    ours.use_chan1 = True
    theirs.useChan1 = True
    ours.play_level_12db = True
    theirs.playLevel12dB = True

    assert bytes(ours.rawdata) == bytes(theirs.rawdata)


def test_slices_match_original():
    ours = Esli()
    theirs = ref_e2s.RIFF_korg_esli()
    for i in (0, 1, 63):
        ours.slices[i].start = i * 100 - 50  # auch negativ (signed)
        ours.slices[i].length = i * 10
        ours.slices[i].attack_length = 5
        ours.slices[i].amplitude = 12345
        theirs.slices[i].start = i * 100 - 50
        theirs.slices[i].length = i * 10
        theirs.slices[i].attack_length = 5
        theirs.slices[i].amplitude = 12345
    ours.slice_steps[0] = 3
    ours.slice_steps[63] = -1
    theirs.sliceSteps[0] = 3
    theirs.sliceSteps[63] = -1
    ours.slicing_num_steps = 16
    ours.slicing_beat = 2
    ours.slices_num_active_steps = 4
    theirs.slicingNumSteps = 16
    theirs.slicingBeat = 2
    theirs.slicesNumActiveSteps = 4
    assert bytes(ours.rawdata) == bytes(theirs.rawdata)


def test_name_roundtrip_and_sanitize():
    esli = Esli()
    esli.name = "Kick 01"
    assert esli.name == "Kick 01"
    esli.name = "ein viel zu langer Samplename"
    assert len(esli.name) <= 16
    assert sanitize_name("äöü<>:") == "______"


def test_osc_num_sets_both_indices():
    esli = Esli()
    esli.osc_num = 501
    assert esli.osc_0index == 500
    assert esli.osc_0index1 == 500
    assert esli.osc_num == 501
