"""WAV-Import: Formate, Optionen, Metadaten-Übernahme."""

import struct

import numpy as np
import pytest

from e2s_manager.core import dsp
from e2s_manager.core.wav_import import EmptyWav, ImportOptions, from_wav

from conftest import make_test_frames, make_wav_bytes


def _write(tmp_path, name, content):
    p = tmp_path / name
    p.write_bytes(content)
    return str(p)


def test_import_16bit_mono(wav_file_mono):
    result = from_wav(wav_file_mono)
    sample = result.sample
    assert result.converted_from is None
    assert sample.fmt.channels == 1
    assert sample.esli.name == "test_mono"
    assert sample.esli.wav_data_size == len(sample.data.rawdata)
    assert sample.esli.one_shot
    assert sample.esli.play_volume == 65535
    assert (
        sample.esli.end_offset
        == len(sample.data.rawdata) - sample.fmt.block_align
    )


@pytest.mark.parametrize("bits", [8, 24, 32])
def test_import_converts_bit_depths(tmp_path, bits):
    frames = make_test_frames(400, 1)
    path = _write(tmp_path, f"b{bits}.wav", make_wav_bytes(frames, bits=bits))
    result = from_wav(path)
    assert result.converted_from == f"{bits} bit"
    fmt = result.sample.fmt
    assert fmt.bit_per_sample == 16
    out = dsp.get_frames(result.sample)
    assert out.shape == frames.shape
    # 8 bit hat nur 8 bit Genauigkeit, sonst nahezu exakt
    tolerance = 256 if bits == 8 else 1
    assert np.max(np.abs(out.astype(int) - frames.astype(int))) <= tolerance


def test_import_float_wav(tmp_path):
    frames = make_test_frames(300, 1)
    floats = (frames.astype(np.float32) / 32767.0).astype("<f4")
    payload = floats.tobytes()
    fmt = struct.pack("<HHIIHH", 3, 1, 44100, 44100 * 4, 4, 32)
    body = (b"WAVE" + b"fmt " + struct.pack("<I", len(fmt)) + fmt
            + b"data" + struct.pack("<I", len(payload)) + payload)
    path = _write(tmp_path, "float.wav",
                  b"RIFF" + struct.pack("<I", len(body)) + body)
    result = from_wav(path)
    assert result.converted_from == "float"
    out = dsp.get_frames(result.sample)
    assert np.max(np.abs(out.astype(int) - frames.astype(int))) <= 1


def test_import_empty_wav_raises(tmp_path):
    path = _write(
        tmp_path, "empty.wav",
        make_wav_bytes(np.zeros((0, 1), dtype=np.int16)),
    )
    with pytest.raises(EmptyWav):
        from_wav(path)


def test_force_mono(wav_file_stereo):
    opts = ImportOptions(force_mono=True, mono_mix=0.0)
    result = from_wav(wav_file_stereo, opts)
    assert result.converted_to_mono
    assert result.sample.fmt.channels == 1
    assert not result.sample.esli.is_stereo


def test_smpl_loop_is_used(tmp_path):
    frames = make_test_frames(500, 1)
    # smpl-Chunk mit einem Loop 100..400
    loop = struct.pack("<6I", 0, 0, 100, 400, 0, 0)
    smpl = struct.pack("<9I", 0, 0, 0, 60, 0, 0, 0, 1, 0) + loop
    chunk = b"smpl" + struct.pack("<I", len(smpl)) + smpl
    path = _write(tmp_path, "looped.wav",
                  make_wav_bytes(frames, extra_chunks=chunk))
    result = from_wav(path)
    esli = result.sample.esli
    assert not esli.one_shot
    assert esli.loop_start_offset == 100 * 2
    assert esli.end_offset == 400 * 2


def test_cue_points_become_slices(tmp_path):
    frames = make_test_frames(1000, 1)
    points = b"".join(
        struct.pack("<2I4s3I", i, pos, b"data", 0, 0, pos)
        for i, pos in enumerate([0, 250, 500, 750])
    )
    cue = struct.pack("<I", 4) + points
    chunk = b"cue " + struct.pack("<I", len(cue)) + cue
    path = _write(tmp_path, "sliced.wav",
                  make_wav_bytes(frames, extra_chunks=chunk))
    result = from_wav(path)
    slices = result.sample.esli.slices
    assert [slices[i].start for i in range(4)] == [0, 250, 500, 750]
    assert [slices[i].length for i in range(4)] == [250, 250, 250, 250]
    assert slices[4].length == 0


def test_auto_trim_silence(tmp_path):
    quiet = np.zeros((2000, 1), dtype=np.int16)
    quiet[900:1100] = 20000
    path = _write(tmp_path, "padded.wav", make_wav_bytes(quiet))
    result = from_wav(path, ImportOptions(auto_trim_silence=True))
    assert result.trimmed_silence
    trimmed = dsp.get_frames(result.sample)
    assert len(trimmed) < 500  # ~200 Frames + Fenster
    esli = result.sample.esli
    assert esli.wav_data_size == len(result.sample.data.rawdata)
    assert esli.end_offset == esli.wav_data_size - 2
