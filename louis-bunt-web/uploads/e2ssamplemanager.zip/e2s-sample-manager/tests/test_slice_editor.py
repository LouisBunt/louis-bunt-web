"""Slice-Editor: Punkte setzen, Steps, Trim - alles undo-fähig."""

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication, QMessageBox

from e2s_manager.core import dsp
from e2s_manager.gui.main_window import MainWindow
from e2s_manager.gui.slice_editor import SliceEditorDialog


@pytest.fixture(scope="session")
def app():
    return QApplication.instance() or QApplication([])


@pytest.fixture
def editor(app, reference_library, monkeypatch):
    win = MainWindow()
    win.action_open(path=reference_library)
    sample = win.doc.library.samples[0]  # mono
    dialog = SliceEditorDialog(win.doc, sample, win.player, win)
    yield win, dialog, sample
    dialog.reject()
    win.doc.undo_stack.setClean()
    win.close()


def test_point_spinboxes_commit(editor):
    win, dialog, sample = editor
    esli = sample.esli
    esli.one_shot = False  # sonst gilt Loop = End
    dialog.spin_start.setValue(10)
    dialog.spin_end.setValue(500)
    dialog.spin_loop.setValue(100)
    dialog._commit_points()
    block = sample.fmt.block_align
    assert esli.start_point_address == 10 * block
    assert esli.loop_start_offset == 90 * block
    assert esli.end_offset == 490 * block
    win.doc.undo_stack.undo()
    assert esli.start_point_address == 0


def test_one_shot_keeps_loop_at_end(editor):
    win, dialog, sample = editor
    assert sample.esli.one_shot
    dialog._on_marker_moved("end", 400)
    assert sample.esli.loop_start_offset == sample.esli.end_offset


def test_marker_moved_updates_esli(editor):
    win, dialog, sample = editor
    dialog._on_marker_moved("end", 400)
    assert sample.esli.end_offset == 400 * sample.fmt.block_align


def test_step_cycle_and_all_off(editor):
    win, dialog, sample = editor
    esli = sample.esli
    dialog.num_steps.setValue(16)
    assert esli.slicing_num_steps == 16
    dialog._all_steps_off()  # Default ist überall Slice 0 (wie am Gerät)
    dialog.slice_select.setValue(2)
    dialog._cycle_step(0)  # aus -> gewählter Slice 2
    assert esli.slice_steps[0] == 2
    dialog._cycle_step(0)  # weiterschalten -> 3
    assert esli.slice_steps[0] == 3
    dialog._set_step(0, -1)
    assert esli.slice_steps[0] == -1
    dialog._set_step(5, 7)
    dialog._all_steps_off()
    assert all(esli.slice_steps[i] == -1 for i in range(64))
    win.doc.undo_stack.undo()  # all_off rückgängig
    # Nach Undo wird der Sample-Inhalt aus dem Snapshot neu aufgebaut,
    # deshalb frisch über sample.esli zugreifen
    assert sample.esli.slice_steps[5] == 7


def test_slice_fields_commit(editor):
    win, dialog, sample = editor
    dialog.slice_select.setValue(0)
    dialog.slice_first.setValue(50)
    dialog.slice_len.setValue(200)
    dialog._commit_slice_fields()
    assert sample.esli.slices[0].start == 50
    assert sample.esli.slices[0].length == 200


def test_trim_via_editor(editor, monkeypatch):
    win, dialog, sample = editor
    frames_before = sample.num_frames
    dialog.spin_start.setValue(100)
    dialog.spin_end.setValue(299)
    dialog._commit_points()
    monkeypatch.setattr(
        QMessageBox, "question", lambda *a, **k: QMessageBox.Yes
    )
    dialog._trim()
    assert sample.num_frames == 200
    assert sample.esli.wav_data_size == 400
    win.doc.undo_stack.undo()
    assert sample.num_frames == frames_before
    assert len(dsp.get_frames(sample)) == frames_before
