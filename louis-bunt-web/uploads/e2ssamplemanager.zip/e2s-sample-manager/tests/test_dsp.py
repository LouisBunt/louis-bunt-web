"""DSP-Funktionen: Mono-Mix, Normalisierung, Trim, Stille-Erkennung."""

import numpy as np

from e2s_manager.core import dsp
from e2s_manager.core.wav_import import from_wav

from conftest import make_test_frames, make_wav_bytes


def _sample_from_frames(tmp_path, frames, name="s.wav"):
    p = tmp_path / name
    p.write_bytes(make_wav_bytes(frames))
    return from_wav(str(p)).sample


def test_to_mono_center_mix(tmp_path):
    stereo = np.zeros((100, 2), dtype=np.int16)
    stereo[:, 0] = 1000
    stereo[:, 1] = 3000
    sample = _sample_from_frames(tmp_path, stereo)
    assert dsp.to_mono(sample, mix=0.0)
    mono = dsp.get_frames(sample)
    assert mono.shape == (100, 1)
    assert abs(int(mono[0, 0]) - 2000) <= 1
    assert sample.esli.wav_data_size == 200


def test_to_mono_left_only(tmp_path):
    stereo = np.zeros((50, 2), dtype=np.int16)
    stereo[:, 0] = 1000
    stereo[:, 1] = 3000
    sample = _sample_from_frames(tmp_path, stereo)
    dsp.to_mono(sample, mix=-1.0)
    assert int(dsp.get_frames(sample)[0, 0]) == 1000


def test_to_mono_halves_points(tmp_path):
    stereo = make_test_frames(200, 2)
    sample = _sample_from_frames(tmp_path, stereo)
    esli = sample.esli
    esli.start_point_address = 40
    esli.loop_start_offset = 100
    end_before = esli.end_offset
    dsp.to_mono(sample)
    assert esli.start_point_address == 20
    assert esli.loop_start_offset == 50
    assert esli.end_offset == end_before // 2


def test_to_mono_on_mono_is_noop(tmp_path):
    sample = _sample_from_frames(tmp_path, make_test_frames(100, 1))
    assert not dsp.to_mono(sample)


def test_normalize(tmp_path):
    quiet = (make_test_frames(300, 1) // 10).astype(np.int16)
    sample = _sample_from_frames(tmp_path, quiet)
    assert dsp.normalize(sample)
    peak = np.max(np.abs(dsp.get_frames(sample).astype(int)))
    assert peak > 32000
    # nochmal: schon normalisiert -> keine Änderung
    assert not dsp.normalize(sample)


def test_normalize_silence_is_noop(tmp_path):
    sample = _sample_from_frames(
        tmp_path, np.zeros((100, 1), dtype=np.int16)
    )
    assert not dsp.normalize(sample)


def test_trim_adjusts_points_and_slices(tmp_path):
    sample = _sample_from_frames(tmp_path, make_test_frames(1000, 1))
    esli = sample.esli
    esli.slices[0].start = 100
    esli.slices[0].length = 800
    esli.slices[1].start = 950
    esli.slices[1].length = 50
    dsp.trim(sample, 100, 899)  # 800 Frames behalten
    assert len(sample.data.rawdata) == 800 * 2
    assert esli.wav_data_size == 1600
    assert esli.end_offset <= 1600 - 2
    # Slice 1 lag hinter dem Ende -> gelöscht
    assert esli.slices[1].length == 0 or esli.slices[1].start <= 799


def test_find_silence_bounds():
    frames = np.zeros((1000, 1), dtype=np.int16)
    frames[400:600] = 15000
    first, last = dsp.find_silence_bounds(frames, threshold_db=-60.0)
    assert 300 <= first <= 400
    assert 600 <= last <= 700


def test_find_silence_bounds_all_quiet():
    frames = np.zeros((500, 1), dtype=np.int16)
    first, last = dsp.find_silence_bounds(frames)
    assert (first, last) == (0, 499)


def test_trim_silence_stereo(tmp_path):
    stereo = np.zeros((1000, 2), dtype=np.int16)
    stereo[400:600] = 18000
    sample = _sample_from_frames(tmp_path, stereo)
    assert dsp.trim_silence(sample)
    frames = dsp.get_frames(sample)
    assert frames.shape[1] == 2
    assert len(frames) < 400
    assert sample.esli.end_offset == len(sample.data.rawdata) - 4
