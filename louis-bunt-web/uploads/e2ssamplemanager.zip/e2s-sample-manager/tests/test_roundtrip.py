"""Format-Round-Trip: unser Port muss sich exakt wie das Original verhalten."""

import io
import os
import struct

import pytest

from e2s_manager.core.library import Library, MAGIC, NUM_SLOTS
from e2s_manager.core.sample import E2sSample


def test_load_reference_library(reference_library):
    lib = Library.load(reference_library)
    assert not lib.load_errors
    assert len(lib) == 3
    assert [s.esli.osc_num for s in lib] == [19, 25, 501]
    assert lib.samples[1].esli.is_stereo


def test_save_is_byte_identical_to_original(reference_library, tmp_path):
    """Laden + Speichern reproduziert die Original-Datei Byte für Byte."""
    lib = Library.load(reference_library)
    out = str(tmp_path / "resaved.all")
    lib.save(out)
    original = open(reference_library, "rb").read()
    resaved = open(out, "rb").read()
    assert resaved == original


def test_save_load_roundtrip_preserves_esli(reference_library, tmp_path):
    lib = Library.load(reference_library)
    esli_raw_before = [bytes(s.esli.rawdata) for s in lib]
    out = str(tmp_path / "roundtrip.all")
    lib.save(out)
    lib2 = Library.load(out)
    esli_raw_after = [bytes(s.esli.rawdata) for s in lib2]
    assert esli_raw_before == esli_raw_after


def test_header_layout(reference_library, tmp_path):
    lib = Library.load(reference_library)
    out = str(tmp_path / "layout.all")
    lib.save(out)
    raw = open(out, "rb").read()
    assert raw[:16] == MAGIC
    offsets = struct.unpack(f"<{NUM_SLOTS}I", raw[16:16 + 4 * NUM_SLOTS])
    # Slot = OSC_0index, erster Datenblock bei 0x1000
    used = [(i, off) for i, off in enumerate(offsets) if off]
    assert used[0][1] == 0x1000
    assert [i + 1 for i, _ in used] == [19, 25, 501]
    for _, off in used:
        assert raw[off:off + 4] == b"RIFF"


def test_atomic_save_leaves_no_temp_files(reference_library, tmp_path):
    lib = Library.load(reference_library)
    out = str(tmp_path / "atomic.all")
    lib.save(out)
    lib.save(out)  # Überschreiben
    leftovers = [f for f in os.listdir(tmp_path) if f.startswith(".e2s_tmp_")]
    assert leftovers == []


def test_corrupt_slot_is_skipped_and_reported(reference_library, tmp_path):
    raw = bytearray(open(reference_library, "rb").read())
    # Offset von Slot 25 (Index 24) auf Unsinn biegen
    struct.pack_into("<I", raw, 16 + 24 * 4, len(raw) - 2)
    broken = tmp_path / "broken.all"
    broken.write_bytes(bytes(raw))
    lib = Library.load(str(broken))
    assert len(lib) == 2
    assert len(lib.load_errors) == 1
    assert "#25" in lib.load_errors[0]


def test_invalid_magic_raises(tmp_path):
    bad = tmp_path / "bad.all"
    bad.write_bytes(b"not a sample all file" + b"\x00" * 5000)
    with pytest.raises(Exception):
        Library.load(str(bad))


def test_sample_write_matches_reference_bytes(reference_library):
    """Einzelnes Sample: read->write reproduziert die Originalbytes."""
    with open(reference_library, "rb") as f:
        raw = f.read()
    offsets = struct.unpack(f"<{NUM_SLOTS}I", raw[16:16 + 4 * NUM_SLOTS])
    used = sorted(off for off in offsets if off)
    first_len = used[1] - used[0]
    original_bytes = raw[used[0]:used[0] + first_len]
    sample = E2sSample(io.BytesIO(original_bytes))
    assert sample.to_bytes() == original_bytes
