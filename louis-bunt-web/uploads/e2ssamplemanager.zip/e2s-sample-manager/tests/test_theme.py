"""Dark Mode: Anwenden und Umschalten."""

import os

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtGui import QPalette
from PySide6.QtWidgets import QApplication

from e2s_manager.gui.theme import DARK, LIGHT, apply_theme


@pytest.fixture(scope="session")
def app():
    return QApplication.instance() or QApplication([])


def test_dark_theme_applies_palette(app):
    apply_theme(app, DARK)
    color = app.palette().color(QPalette.Window)
    assert color.lightness() < 100  # dunkler Hintergrund
    assert app.styleSheet() != ""


def test_light_theme_resets(app):
    apply_theme(app, DARK)
    apply_theme(app, LIGHT)
    assert app.styleSheet() == ""
    color = app.palette().color(QPalette.Window)
    assert color.lightness() > 100
