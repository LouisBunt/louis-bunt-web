# E2S Sample Manager

Ein moderner Sample-Library-Manager für die **Korg Electribe 2 Sampler**
(funktioniert auch mit [Hacktribe](https://github.com/bangcorrupt/hacktribe)-Firmware).
Bearbeitet die `e2sSample.all`-Datei auf der SD-Karte
(`KORG/electribe sampler/Sample/e2sSample.all`).

Neuimplementierung von [Oe2sSLE](https://github.com/JonathanTaquet/Oe2sSLE)
(Jonathan Taquet, GPL-3) mit stabiler Qt-Oberfläche und vielen
Quality-of-Life-Funktionen, die dem Original fehlen.

## Features

**Alles aus dem Original:**
- e2sSample.all öffnen, bearbeiten, speichern (byteidentisches Format)
- WAV-Import (8/16/24/32-bit PCM und Float, mono/stereo, smpl-Loops und
  cue-Slices werden übernommen), Import aus anderen `.all`-Dateien
- Export als WAV (einzeln/alle), optional mit smpl/cue-Chunks für die DAW
- Name, Nummer, Kategorie, 1-Shot, +12dB, Tune, Frequenz direkt in der
  Tabelle editieren; Factory-Samples ersetzen/löschen
- Start/Loop/End-Punkte und bis zu 64 Slices mit Step-Zuordnung bearbeiten
- Verschieben/Tauschen von Samples inkl. der Electribe-Nummernregeln
  (19–421 und 501–999, die Lücke 422–500 wird automatisch übersprungen)
- Speicherlimit-Anzeige (25 MB Sample-RAM) als Balken

**Neu (Quality of Life):**
- **Undo/Redo für alles** (Ctrl+Z / Ctrl+Y) – auch Löschen, Ersetzen,
  Trim und Mono-Konvertierung sind rückgängig machbar
- **Auto-Backup**: vor jedem Speichern landet eine Kopie in
  `e2sSample.all.backup/` (rotierend, die letzten 10)
- **Atomares Speichern**: ein Absturz beim Schreiben zerstört nie die
  bestehende Datei
- **Drag & Drop**: WAVs ins Fenster ziehen zum Importieren, Zeilen ziehen
  zum Umsortieren
- **Auto-Trim**: Stille am Anfang/Ende automatisch abschneiden
  (beim Import oder als Batch-Aktion, Schwelle einstellbar)
- **Auto-Mono**: Stereo→Mono mit Pan-Mix, einzeln oder für viele auf einmal
- **Batch-Bearbeitung**: mehrere Samples markieren → Kategorie setzen,
  normalisieren, trimmen, umbenennen mit Muster, exportieren, löschen
- **Suche, Filter, Sortierung** über der Tabelle
- **SD-Karten-Erkennung**: „SD-Karte öffnen“ findet die Library automatisch
- Waveform-Editor mit Mausrad-Zoom, ziehbaren Markern und
  Nulldurchgang-Einrasten; Slice-Steps als klickbares Grid
- **Dark Mode** (Standard, umschaltbar über Ansicht → Dark Mode oder
  Ctrl+D, Auswahl wird gemerkt)
- Defekte Samples in einer Library werden übersprungen und gemeldet
  statt das Laden abbrechen zu lassen

## Screenshots

![Hauptfenster (Dark Mode)](doc/screenshot_main_dark.png)

![Waveform-/Slice-Editor (Dark Mode)](doc/screenshot_editor_dark.png)

![Hauptfenster (Hell)](doc/screenshot_main.png)

## Installation

### Windows – der einfache Weg

Einmalig [Python](https://www.python.org/downloads/) installieren
(Haken bei „Add python.exe to PATH" setzen), dann:

- **`Start-E2S-Sample-Manager.bat`** doppelklicken – richtet sich beim
  ersten Start selbst ein (1–2 Minuten) und startet danach sofort.
- **`build-exe.bat`** doppelklicken, wenn du eine echte
  **`E2S-Sample-Manager.exe`** haben willst: nach ein paar Minuten liegt
  sie in `dist\` und läuft dann überall ohne Python (auf den Desktop
  kopieren, fertig).

Alternativ baut der GitHub-Actions-Workflow
(`.github/workflows/build-windows-exe.yml`) die Exe automatisch in der
Cloud – im Repo unter *Actions → Build Windows EXE → Artifacts*
herunterladen.

### Manuell (alle Systeme)

Python ≥ 3.10, dann:

```bash
cd e2s-sample-manager
pip install .
e2s-sample-manager
```

oder direkt aus dem Quellcode:

```bash
pip install PySide6-Essentials numpy sounddevice psutil
python -m e2s_manager
```

## Workflow mit der Electribe

1. Am Gerät: `DATA UTILITY` → `EXPORT ALL SAMPLE` (schreibt die
   `e2sSample.all` auf die SD-Karte)
2. SD-Karte in den Rechner, App starten, **SD-Karte öffnen**
3. Bearbeiten, **Speichern** (Backup passiert automatisch)
4. SD-Karte zurück in die Electribe und neu starten – die Library wird
   beim Booten geladen

> Alternativ die Datei unter anderem Namen (`*.all`) speichern und am
> Gerät über `DATA UTILITY` → `IMPORT SAMPLE` laden.

## Entwicklung

```bash
pip install pytest
QT_QPA_PLATFORM=offscreen python -m pytest tests/
```

Die Tests in `tests/test_roundtrip.py` prüfen das Dateiformat
**byteidentisch** gegen den Original-Oe2sSLE-Code (liegt in
`tests/reference/`).

Geplant (Phase 2): MIDI/SysEx-Anbindung für Hacktribe
(Geräteerkennung, Pattern-Backup/-Restore) auf Basis von
[hacktribe/scripts/e2sysex.py](https://github.com/bangcorrupt/hacktribe).
Der Modul-Platzhalter ist `e2s_manager/midi/`.

## Lizenz

GPL-3.0-or-later. Formatlogik portiert aus Oe2sSLE,
Copyright (C) 2015–2018 Jonathan Taquet.
