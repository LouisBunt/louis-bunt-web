"""Launcher für PyInstaller-Builds (siehe build-exe.bat)."""

import sys

from e2s_manager.__main__ import main

if __name__ == "__main__":
    sys.exit(main())
