@echo off
rem ============================================================
rem  E2S Sample Manager - Ein-Klick-Starter (ohne Exe-Build)
rem  Beim ersten Doppelklick wird alles automatisch installiert
rem  (dauert einmalig 1-2 Minuten), danach startet die App sofort.
rem  Voraussetzung: Python 3.10+ von https://python.org
rem ============================================================
cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
    echo Python wurde nicht gefunden!
    echo Bitte von https://www.python.org/downloads/ installieren
    echo und dabei "Add python.exe to PATH" anhaken.
    pause
    exit /b 1
)

if not exist ".venv\Scripts\pythonw.exe" (
    echo Erste Einrichtung, bitte kurz warten ...
    py -3 -m venv .venv || (pause & exit /b 1)
    ".venv\Scripts\python.exe" -m pip install --upgrade pip
    ".venv\Scripts\python.exe" -m pip install PySide6-Essentials numpy sounddevice psutil || (pause & exit /b 1)
)

start "" ".venv\Scripts\pythonw.exe" -m e2s_manager
