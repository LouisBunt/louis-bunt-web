"""SD-Karten mit Electribe-Sample-Library finden."""

from __future__ import annotations

import os

try:
    import psutil
except ImportError:  # psutil ist optional, dann nur manuelles Öffnen
    psutil = None

SAMPLE_SUBPATH = os.path.join("KORG", "electribe sampler", "Sample")
SAMPLE_FILENAME = "e2sSample.all"


def find_sample_all_paths() -> list[str]:
    """Alle e2sSample.all-Dateien auf eingehängten (Wechsel-)Laufwerken."""
    found = []
    if psutil is None:
        return found
    for part in psutil.disk_partitions(all=False):
        candidate = os.path.join(part.mountpoint, SAMPLE_SUBPATH, SAMPLE_FILENAME)
        try:
            if os.path.isfile(candidate):
                found.append(candidate)
        except OSError:
            continue
    return found
