"""Rotierendes Auto-Backup vor jedem Überschreiben einer Library."""

from __future__ import annotations

import os
import shutil
import time

BACKUP_DIRNAME_SUFFIX = ".backup"
DEFAULT_KEEP = 10


def backup_file(path: str, keep: int = DEFAULT_KEEP) -> str | None:
    """Kopie von path in den Backup-Ordner legen; alte Backups rotieren.

    Gibt den Pfad des Backups zurück, oder None wenn path nicht existiert.
    """
    if not os.path.isfile(path):
        return None
    base, ext = os.path.splitext(os.path.basename(path))
    backup_dir = path + BACKUP_DIRNAME_SUFFIX
    os.makedirs(backup_dir, exist_ok=True)
    stamp = time.strftime("%Y%m%d_%H%M%S")
    target = os.path.join(backup_dir, f"{base}_{stamp}{ext}")
    # Kollision bei mehreren Speichervorgängen in derselben Sekunde
    counter = 1
    while os.path.exists(target):
        target = os.path.join(backup_dir, f"{base}_{stamp}_{counter}{ext}")
        counter += 1
    shutil.copy2(path, target)
    _rotate(backup_dir, base, ext, keep)
    return target


def _rotate(backup_dir: str, base: str, ext: str, keep: int) -> None:
    entries = sorted(
        f for f in os.listdir(backup_dir)
        if f.startswith(base + "_") and f.endswith(ext)
    )
    for old in entries[:-keep]:
        try:
            os.unlink(os.path.join(backup_dir, old))
        except OSError:
            pass
