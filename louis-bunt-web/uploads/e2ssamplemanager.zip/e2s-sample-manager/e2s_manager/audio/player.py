"""Audio-Vorschau über sounddevice (deutlich stabiler als pyaudio).

Läuft komplett in einem Callback-Stream; wenn kein Audiogerät verfügbar
ist, degradiert der Player still (Play-Buttons tun dann nichts, statt
die App zu crashen - eine der Hauptabsturzquellen des Originals).
"""

from __future__ import annotations

import threading

import numpy as np

try:
    import sounddevice as sd
    _HAVE_AUDIO = True
except (ImportError, OSError):  # OSError: keine PortAudio-Bibliothek
    sd = None
    _HAVE_AUDIO = False

from ..core import dsp
from ..core.sample import E2sSample


class Player:
    """Spielt genau ein Sample gleichzeitig ab (wie das Original)."""

    def __init__(self):
        self._lock = threading.Lock()
        self._stream = None

    @property
    def available(self) -> bool:
        return _HAVE_AUDIO

    def play_sample(self, sample: E2sSample, use_points: bool = False,
                    loop: bool = False) -> None:
        """Sample abspielen.

        use_points=True beachtet Start/End (und Loop bei loop=True),
        sonst wird der komplette WAV-Inhalt gespielt.
        """
        if not _HAVE_AUDIO:
            return
        frames = dsp.get_frames(sample).astype(np.float32) / 32768.0
        if not len(frames):
            return
        esli = sample.esli
        freq = esli.sampling_freq or sample.fmt.samples_per_sec or 44100
        block = sample.fmt.block_align or 2

        start = 0
        end = len(frames)
        loop_start = 0
        if use_points:
            start = min(esli.start_point_address // block, len(frames) - 1)
            end = min((esli.start_point_address + esli.end_offset) // block + 1,
                      len(frames))
            loop_start = min(
                (esli.start_point_address + esli.loop_start_offset) // block,
                end - 1,
            )
            loop = loop and not esli.one_shot and loop_start < end - 1

        self.stop()
        self._start_stream(frames, freq, start, end, loop_start, loop)

    def _start_stream(self, frames: np.ndarray, freq: int, start: int,
                      end: int, loop_start: int, loop: bool) -> None:
        channels = frames.shape[1]
        state = {"pos": start}

        def callback(outdata, num_frames, time_info, status):
            pos = state["pos"]
            written = 0
            while written < num_frames:
                chunk = min(num_frames - written, end - pos)
                if chunk <= 0:
                    if loop:
                        pos = loop_start
                        continue
                    outdata[written:] = 0
                    state["pos"] = pos
                    raise sd.CallbackStop
                outdata[written:written + chunk] = frames[pos:pos + chunk]
                pos += chunk
                written += chunk
            state["pos"] = pos

        try:
            stream = sd.OutputStream(
                samplerate=freq, channels=channels, dtype="float32",
                callback=callback,
            )
            stream.start()
        except Exception:
            return  # Gerät belegt/ungültige Rate: Vorschau still auslassen
        with self._lock:
            self._stream = stream

    def stop(self) -> None:
        with self._lock:
            stream, self._stream = self._stream, None
        if stream is not None:
            try:
                stream.abort()
                stream.close()
            except Exception:
                pass
