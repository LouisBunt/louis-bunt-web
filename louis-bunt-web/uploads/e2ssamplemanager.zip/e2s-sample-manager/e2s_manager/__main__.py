"""Einstiegspunkt: python -m e2s_manager [datei.all] [--self-test]"""

from __future__ import annotations

import sys


def main() -> int:
    from PySide6.QtWidgets import QApplication

    from . import APP_NAME
    from .gui.main_window import MainWindow

    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    self_test = "--self-test" in sys.argv

    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)

    from .gui.theme import apply_theme
    apply_theme(app, MainWindow._settings_theme())

    window = MainWindow()
    window.show()

    if args:
        window.action_open(path=args[0])

    if self_test:
        # Headless-Smoke-Test: Fenster aufbauen, Events verarbeiten, beenden
        from PySide6.QtCore import QTimer
        QTimer.singleShot(500, app.quit)
        app.exec()
        print("self-test ok")
        return 0

    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
