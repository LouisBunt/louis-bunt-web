"""Editor für Start/Loop/End-Punkte und Slices eines Samples.

Bedienkonzept gegenüber dem Original vereinfacht:
- Punkte per Drag in der Waveform (mit Nulldurchgang-Snap) oder Spinbox
- Slice-Auswahl per Liste, First/Last des gewählten Slices sind Marker
- Step-Zuordnung als klickbares 4x16-Grid statt 64 Spinboxen
"""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QGridLayout, QGroupBox, QHBoxLayout,
    QLabel, QMessageBox, QPushButton, QSpinBox, QVBoxLayout,
)

from ..core import dsp
from ..core.esli import BEAT_NAMES, NUM_SLICES, NUM_STEPS
from ..audio.player import Player
from .commands import SetLoopPointsCommand, TransformSampleCommand
from .document import Document
from .waveform import WaveformWidget


class StepButton(QPushButton):
    """Ein Step im Grid: zeigt die Slice-Nummer oder '-' (aus)."""

    def __init__(self, step: int):
        super().__init__("-")
        self.step = step
        self.setFixedSize(34, 26)
        self.setToolTip(
            f"Step {step + 1}: Klick = Slice zuweisen, Rechtsklick = aus"
        )


class SliceEditorDialog(QDialog):
    def __init__(self, doc: Document, sample, player: Player, parent=None):
        super().__init__(parent)
        self.doc = doc
        self.sample = sample
        self.player = player
        esli = sample.esli
        self.setWindowTitle(f"Sample bearbeiten - #{esli.osc_num:03d} {esli.name}")
        self.resize(980, 700)

        self._block = sample.fmt.block_align or 2
        self._updating = False

        layout = QVBoxLayout(self)

        self.waveform = WaveformWidget()
        self.waveform.marker_moved.connect(self._on_marker_moved)
        layout.addWidget(self.waveform, stretch=2)

        snap = QCheckBox("Marker auf Nulldurchgänge einrasten")
        snap.setChecked(True)
        snap.toggled.connect(
            lambda on: setattr(self.waveform, "snap_zero_crossing", on)
        )
        layout.addWidget(snap)

        # --- Punkte ---
        points_box = QGroupBox("Sample-Punkte")
        points_row = QHBoxLayout(points_box)
        max_frame = max(0, sample.num_frames - 1)
        self.spin_start = self._make_point_spin(points_row, "Start:", max_frame)
        self.spin_loop = self._make_point_spin(points_row, "Loop:", max_frame)
        self.spin_end = self._make_point_spin(points_row, "End:", max_frame)

        self.play_button = QPushButton("Anhören (mit Punkten)")
        self.play_button.clicked.connect(self._play_points)
        points_row.addWidget(self.play_button)
        stop_button = QPushButton("Stop")
        stop_button.clicked.connect(self.player.stop)
        points_row.addWidget(stop_button)
        trim_button = QPushButton("Auf Start/End trimmen")
        trim_button.clicked.connect(self._trim)
        points_row.addWidget(trim_button)
        layout.addWidget(points_box)

        # --- Slices ---
        slices_box = QGroupBox("Slices")
        slices_layout = QVBoxLayout(slices_box)
        select_row = QHBoxLayout()
        select_row.addWidget(QLabel("Slice:"))
        self.slice_select = QSpinBox()
        self.slice_select.setRange(0, NUM_SLICES - 1)
        self.slice_select.valueChanged.connect(self._refresh_slice_fields)
        select_row.addWidget(self.slice_select)
        select_row.addWidget(QLabel("Anfang:"))
        self.slice_first = QSpinBox()
        self.slice_first.setRange(-(2**31), 2**31 - 1)
        self.slice_first.editingFinished.connect(self._commit_slice_fields)
        select_row.addWidget(self.slice_first)
        select_row.addWidget(QLabel("Länge:"))
        self.slice_len = QSpinBox()
        self.slice_len.setRange(0, 2**31 - 1)
        self.slice_len.editingFinished.connect(self._commit_slice_fields)
        select_row.addWidget(self.slice_len)

        select_row.addWidget(QLabel("Steps:"))
        self.num_steps = QSpinBox()
        self.num_steps.setRange(0, NUM_STEPS)
        self.num_steps.setValue(esli.slicing_num_steps)
        self.num_steps.valueChanged.connect(self._commit_step_meta)
        select_row.addWidget(self.num_steps)
        select_row.addWidget(QLabel("Beat:"))
        self.beat = QComboBox()
        for name in BEAT_NAMES.values():
            self.beat.addItem(name)
        self.beat.setCurrentIndex(min(esli.slicing_beat, 3))
        self.beat.currentIndexChanged.connect(self._commit_step_meta)
        select_row.addWidget(self.beat)
        all_off = QPushButton("Alle Steps aus")
        all_off.clicked.connect(self._all_steps_off)
        select_row.addWidget(all_off)
        select_row.addStretch(1)
        slices_layout.addLayout(select_row)

        grid = QGridLayout()
        grid.setSpacing(2)
        self.step_buttons: list[StepButton] = []
        for step in range(NUM_STEPS):
            button = StepButton(step)
            button.clicked.connect(
                lambda checked=False, s=step: self._cycle_step(s)
            )
            button.setContextMenuPolicy(Qt.CustomContextMenu)
            button.customContextMenuRequested.connect(
                lambda pos, s=step: self._set_step(s, -1)
            )
            grid.addWidget(button, step // 16, step % 16)
            self.step_buttons.append(button)
        slices_layout.addLayout(grid)
        hint = QLabel(
            "Klick: Step auf den gewählten Slice setzen / weiterschalten - "
            "Rechtsklick: Step aus. Slices funktionieren nur bei Mono-Samples."
        )
        hint.setWordWrap(True)
        slices_layout.addWidget(hint)
        layout.addWidget(slices_box)

        close_button = QPushButton("Schließen")
        close_button.clicked.connect(self.accept)
        layout.addWidget(close_button, alignment=Qt.AlignRight)

        self._load_waveform()
        self._refresh_all()

        if sample.esli.is_stereo:
            QMessageBox.information(
                self, "Stereo-Sample",
                "Dieses Sample ist stereo - die Electribe kann Slices nur "
                "bei Mono-Samples abspielen. Konvertiere es ggf. zu Mono "
                "(Haken in der Stereo-Spalte entfernen).",
            )

    # --- Aufbau-Helfer ---

    def _make_point_spin(self, row: QHBoxLayout, label: str, maximum: int) -> QSpinBox:
        row.addWidget(QLabel(label))
        spin = QSpinBox()
        spin.setRange(0, max(0, maximum))
        spin.editingFinished.connect(self._commit_points)
        row.addWidget(spin)
        return spin

    def _load_waveform(self) -> None:
        self.waveform.set_frames(dsp.get_frames(self.sample))

    # --- Ansicht aktualisieren ---

    def _point_frames(self) -> tuple[int, int, int]:
        esli = self.sample.esli
        start = esli.start_point_address // self._block
        loop = (esli.start_point_address + esli.loop_start_offset) // self._block
        end = (esli.start_point_address + esli.end_offset) // self._block
        return start, loop, end

    def _refresh_all(self) -> None:
        self._updating = True
        start, loop, end = self._point_frames()
        self.spin_start.setValue(start)
        self.spin_loop.setValue(loop)
        self.spin_end.setValue(end)
        esli = self.sample.esli
        self.num_steps.setValue(esli.slicing_num_steps)
        self.beat.setCurrentIndex(min(esli.slicing_beat, 3))
        self._updating = False
        self._refresh_slice_fields()
        self._refresh_steps()
        self._refresh_markers()

    def _refresh_markers(self) -> None:
        start, loop, end = self._point_frames()
        markers = {"start": start, "loop": loop, "end": end}
        sl = self.sample.esli.slices[self.slice_select.value()]
        if sl.length > 0:
            markers["slice_first"] = max(0, sl.start)
            markers["slice_last"] = max(0, sl.start + sl.length - 1)
        self.waveform.set_markers(markers)

    def _refresh_slice_fields(self) -> None:
        self._updating = True
        sl = self.sample.esli.slices[self.slice_select.value()]
        self.slice_first.setValue(sl.start)
        self.slice_len.setValue(sl.length)
        self._updating = False
        self._refresh_markers()

    def _refresh_steps(self) -> None:
        esli = self.sample.esli
        active = 0
        for step, button in enumerate(self.step_buttons):
            value = esli.slice_steps[step]
            button.setText("-" if value < 0 else str(value))
            button.setEnabled(step < esli.slicing_num_steps)
            if value >= 0 and step < esli.slicing_num_steps:
                active += 1

    # --- Änderungen anwenden ---

    def _on_marker_moved(self, name: str, frame: int) -> None:
        if name == "start":
            self.spin_start.setValue(frame)
            self._commit_points()
        elif name == "loop":
            self.spin_loop.setValue(frame)
            self._commit_points()
        elif name == "end":
            self.spin_end.setValue(frame)
            self._commit_points()
        elif name in ("slice_first", "slice_last"):
            sl = self.sample.esli.slices[self.slice_select.value()]
            if name == "slice_first":
                last = sl.start + sl.length - 1
                self.slice_first.setValue(min(frame, last))
                self.slice_len.setValue(max(1, last - self.slice_first.value() + 1))
            else:
                self.slice_len.setValue(max(1, frame - sl.start + 1))
            self._commit_slice_fields()

    def _commit_points(self) -> None:
        if self._updating:
            return
        esli = self.sample.esli
        start = self.spin_start.value()
        end = max(start, self.spin_end.value())
        if esli.one_shot:
            # Electribe-Regel: bei One-Shot ist Loop immer gleich End
            loop = end
        else:
            loop = min(max(start, self.spin_loop.value()), end)
        new = (
            start * self._block,
            (loop - start) * self._block,
            (end - start) * self._block,
            esli.one_shot,
        )
        old = (esli.start_point_address, esli.loop_start_offset,
               esli.end_offset, esli.one_shot)
        if new != old:
            self.doc.undo_stack.push(SetLoopPointsCommand(
                self.doc, self.sample, *new,
                f"Punkte von '{esli.name}'",
            ))
        self._refresh_all()

    def _commit_slice_fields(self) -> None:
        if self._updating:
            return
        index = self.slice_select.value()
        first = self.slice_first.value()
        length = self.slice_len.value()

        def apply(sample) -> bool:
            sl = sample.esli.slices[index]
            if sl.start == first and sl.length == length:
                return False
            sl.start = first
            sl.length = length
            return True

        command = TransformSampleCommand(
            self.doc, self.sample, apply,
            f"Slice {index} von '{self.sample.esli.name}'",
        )
        if command.changed:
            self.doc.undo_stack.push(command)
        self._refresh_markers()

    def _commit_step_meta(self) -> None:
        if self._updating:
            return
        steps = self.num_steps.value()
        beat = self.beat.currentIndex()

        def apply(sample) -> bool:
            esli = sample.esli
            if esli.slicing_num_steps == steps and esli.slicing_beat == beat:
                return False
            esli.slicing_num_steps = steps
            esli.slicing_beat = beat
            esli.slices_num_active_steps = self._count_active(esli, steps)
            return True

        command = TransformSampleCommand(
            self.doc, self.sample, apply,
            f"Slice-Steps von '{self.sample.esli.name}'",
        )
        if command.changed:
            self.doc.undo_stack.push(command)
        self._refresh_steps()

    @staticmethod
    def _count_active(esli, num_steps: int) -> int:
        return sum(
            1 for i in range(num_steps) if esli.slice_steps[i] >= 0
        )

    def _cycle_step(self, step: int) -> None:
        current = self.sample.esli.slice_steps[step]
        self._set_step(
            step,
            self.slice_select.value() if current < 0 else current + 1,
        )

    def _set_step(self, step: int, value: int) -> None:
        if value >= NUM_SLICES:
            value = -1

        def apply(sample) -> bool:
            esli = sample.esli
            if esli.slice_steps[step] == value:
                return False
            esli.slice_steps[step] = value
            esli.slices_num_active_steps = self._count_active(
                esli, esli.slicing_num_steps
            )
            return True

        command = TransformSampleCommand(
            self.doc, self.sample, apply,
            f"Step {step + 1} von '{self.sample.esli.name}'",
        )
        if command.changed:
            self.doc.undo_stack.push(command)
        self._refresh_steps()

    def _all_steps_off(self) -> None:
        def apply(sample) -> bool:
            esli = sample.esli
            changed = False
            for i in range(NUM_STEPS):
                if esli.slice_steps[i] != -1:
                    esli.slice_steps[i] = -1
                    changed = True
            if changed:
                esli.slices_num_active_steps = 0
            return changed

        command = TransformSampleCommand(
            self.doc, self.sample, apply,
            f"Alle Steps aus für '{self.sample.esli.name}'",
        )
        if command.changed:
            self.doc.undo_stack.push(command)
        self._refresh_steps()

    def _play_points(self) -> None:
        self.player.play_sample(self.sample, use_points=True, loop=True)

    def _trim(self) -> None:
        start, _, end = self._point_frames()
        if end <= start:
            return
        answer = QMessageBox.question(
            self, "Trimmen",
            "Audio außerhalb von Start/End wird entfernt (rückgängig "
            "machbar über Bearbeiten > Rückgängig). Fortfahren?",
        )
        if answer != QMessageBox.Yes:
            return
        command = TransformSampleCommand(
            self.doc, self.sample,
            lambda sample: (dsp.trim(sample, start, end), True)[1],
            f"Trim '{self.sample.esli.name}'",
        )
        self.doc.undo_stack.push(command)
        self._load_waveform()
        self._refresh_all()

    def done(self, result: int) -> None:
        self.player.stop()
        super().done(result)
