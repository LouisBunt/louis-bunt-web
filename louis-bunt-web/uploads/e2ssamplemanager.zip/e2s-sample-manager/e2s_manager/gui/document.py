"""Das zentrale Dokument: Library + Undo-Stack + Änderungs-Signale.

Alle Mutationen laufen über QUndoCommands (siehe commands.py), damit
jede Aktion rückgängig gemacht werden kann - im Original sind Löschen,
Ersetzen und Trim endgültig.
"""

from __future__ import annotations

from PySide6.QtCore import QObject, Signal
from PySide6.QtGui import QUndoStack

from ..core.library import Library, is_valid_num, next_valid_num
from ..core.sample import E2sSample


class Document(QObject):
    # Struktur geändert (Samples hinzugefügt/entfernt/umsortiert)
    structure_changed = Signal()
    # Ein einzelnes Sample geändert (Index in library.samples)
    sample_changed = Signal(int)
    # Pfad/Titel geändert
    path_changed = Signal()

    def __init__(self, parent: QObject | None = None):
        super().__init__(parent)
        self.library = Library()
        self.path: str | None = None
        self.undo_stack = QUndoStack(self)

    # --- Datei-Lebenszyklus ---

    def new(self) -> None:
        self.library = Library()
        self.path = None
        self.undo_stack.clear()
        self.structure_changed.emit()
        self.path_changed.emit()

    def open(self, path: str) -> list[str]:
        library = Library.load(path)
        self.library = library
        self.path = path
        self.undo_stack.clear()
        self.structure_changed.emit()
        self.path_changed.emit()
        return library.load_errors

    def save(self, path: str | None = None) -> str:
        target = path or self.path
        if not target:
            raise ValueError("Kein Dateiname zum Speichern")
        self.library.save(target)
        self.path = target
        self.undo_stack.setClean()
        self.path_changed.emit()
        return target

    @property
    def dirty(self) -> bool:
        return not self.undo_stack.isClean()

    # --- Hilfen für Commands/Views ---

    def index_of(self, sample: E2sSample) -> int:
        return self.library.samples.index(sample)

    def notify_sample_changed(self, sample: E2sSample) -> None:
        try:
            self.sample_changed.emit(self.index_of(sample))
        except ValueError:
            pass

    def notify_structure_changed(self) -> None:
        self.structure_changed.emit()

    # --- Nummernvergabe mit "Schieben" (Logik der Original-GUI) ---

    def plan_renumber(self, sample: E2sSample, new_num: int) -> dict[E2sSample, int] | None:
        """Plant sample->new_num; Nachbarn werden bei Konflikt verschoben.

        Gibt {sample: neue Nummer} zurück oder None, wenn kein Platz ist.
        """
        if not is_valid_num(new_num):
            return None
        samples = sorted(self.library.samples, key=lambda s: s.esli.osc_0index)
        idx = samples.index(sample)
        changes: dict[E2sSample, int] = {sample: new_num}

        def num_of(s: E2sSample) -> int:
            return changes.get(s, s.esli.osc_num)

        if new_num < sample.esli.osc_num:
            for j in range(idx - 1, -1, -1):
                if num_of(samples[j]) < num_of(samples[j + 1]):
                    break
                prev = next_valid_num(num_of(samples[j + 1]), -1)
                if prev is None:
                    return None
                changes[samples[j]] = prev
        elif new_num > sample.esli.osc_num:
            for j in range(idx + 1, len(samples)):
                if num_of(samples[j]) > num_of(samples[j - 1]):
                    break
                nxt = next_valid_num(num_of(samples[j - 1]), 1)
                if nxt is None:
                    return None
                changes[samples[j]] = nxt

        return {s: n for s, n in changes.items() if n != s.esli.osc_num}
