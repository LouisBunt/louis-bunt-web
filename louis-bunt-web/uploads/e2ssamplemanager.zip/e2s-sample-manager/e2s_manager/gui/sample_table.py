"""Die Sample-Tabelle: Inline-Editing, Datei-Drop und Drag-Umsortierung."""

from __future__ import annotations

import os

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QStyledItemDelegate, QTableView,
)

from ..core.esli import OSC_CATEGORY_NAMES
from .sample_model import COL_CAT, SampleFilterProxy, SampleTableModel

AUDIO_EXTENSIONS = (".wav", ".wave")
LIBRARY_EXTENSIONS = (".all",)


class CategoryDelegate(QStyledItemDelegate):
    """Dropdown für die Kategorie-Spalte."""

    def createEditor(self, parent, option, index):
        box = QComboBox(parent)
        for name in OSC_CATEGORY_NAMES.values():
            box.addItem(name)
        return box

    def setEditorData(self, editor, index):
        editor.setCurrentText(index.data(Qt.EditRole))

    def setModelData(self, editor, model, index):
        model.setData(index, editor.currentText(), Qt.EditRole)


class SampleTableView(QTableView):
    files_dropped = Signal(list)  # Liste von Dateipfaden
    rows_move_requested = Signal(list, int)  # Quell-Zeilen, Ziel-Zeile (source-Model)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.setSortingEnabled(True)
        self.setAcceptDrops(True)
        self.setDragEnabled(True)
        self.setDropIndicatorShown(True)
        self.setDragDropMode(QAbstractItemView.DragDrop)
        self.setAlternatingRowColors(True)
        self.verticalHeader().setVisible(False)
        self.setItemDelegateForColumn(COL_CAT, CategoryDelegate(self))
        self.setEditTriggers(
            QAbstractItemView.DoubleClicked | QAbstractItemView.EditKeyPressed
        )

    # --- Hilfen ---

    def _source_model(self) -> SampleTableModel:
        model = self.model()
        if isinstance(model, SampleFilterProxy):
            return model.sourceModel()
        return model

    def selected_source_rows(self) -> list[int]:
        model = self.model()
        rows = set()
        for index in self.selectionModel().selectedRows():
            if isinstance(model, SampleFilterProxy):
                index = model.mapToSource(index)
            rows.add(index.row())
        return sorted(rows)

    @staticmethod
    def _dropped_files(mime) -> list[str]:
        files = []
        if mime.hasUrls():
            for url in mime.urls():
                path = url.toLocalFile()
                if path and os.path.splitext(path)[1].lower() in (
                    AUDIO_EXTENSIONS + LIBRARY_EXTENSIONS
                ):
                    files.append(path)
        return files

    # --- Drag & Drop ---

    def dragEnterEvent(self, event):
        if self._dropped_files(event.mimeData()) or event.source() is self:
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event):
        if self._dropped_files(event.mimeData()) or event.source() is self:
            event.acceptProposedAction()
        else:
            super().dragMoveEvent(event)

    def dropEvent(self, event):
        files = self._dropped_files(event.mimeData())
        if files:
            event.acceptProposedAction()
            self.files_dropped.emit(files)
            return
        if event.source() is self:
            # interne Umsortierung: Auswahl an die Zielzeile verschieben
            model = self.model()
            index = self.indexAt(event.position().toPoint())
            if isinstance(model, SampleFilterProxy):
                if index.isValid():
                    index = model.mapToSource(index)
                target_row = index.row() if index.isValid() else (
                    self._source_model().rowCount() - 1
                )
            else:
                target_row = index.row() if index.isValid() else (
                    model.rowCount() - 1
                )
            rows = self.selected_source_rows()
            if rows and target_row >= 0:
                event.acceptProposedAction()
                self.rows_move_requested.emit(rows, target_row)
            return
        super().dropEvent(event)
