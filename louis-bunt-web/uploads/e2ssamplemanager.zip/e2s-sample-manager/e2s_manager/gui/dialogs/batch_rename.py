"""Batch-Umbenennen mit Muster (QoL, neu gegenüber dem Original)."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QCheckBox, QDialog, QDialogButtonBox, QFormLayout, QLabel, QLineEdit,
    QSpinBox, QVBoxLayout,
)

from ...core.esli import sanitize_name


class BatchRenameDialog(QDialog):
    """Präfix/Suffix/Basisname + fortlaufende Nummer für viele Samples."""

    def __init__(self, names: list[str], parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"{len(names)} Samples umbenennen")
        self._names = names

        form = QFormLayout()
        self.base = QLineEdit()
        self.base.setPlaceholderText("leer = Originalname behalten")
        form.addRow("Neuer Basisname:", self.base)
        self.prefix = QLineEdit()
        form.addRow("Präfix:", self.prefix)
        self.suffix = QLineEdit()
        form.addRow("Suffix:", self.suffix)
        self.number = QCheckBox("fortlaufend nummerieren")
        form.addRow(self.number)
        self.number_start = QSpinBox()
        self.number_start.setRange(0, 999)
        self.number_start.setValue(1)
        form.addRow("Start bei:", self.number_start)

        self.preview = QLabel()
        form.addRow("Vorschau:", self.preview)

        for widget in (self.base, self.prefix, self.suffix):
            widget.textChanged.connect(self._update_preview)
        self.number.toggled.connect(self._update_preview)
        self.number_start.valueChanged.connect(self._update_preview)
        self._update_preview()

        buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(buttons)

    def new_names(self) -> list[str]:
        result = []
        for i, old in enumerate(self._names):
            name = self.base.text() or old
            name = self.prefix.text() + name + self.suffix.text()
            if self.number.isChecked():
                name = f"{name}{self.number_start.value() + i:02d}"
            result.append(sanitize_name(name))
        return result

    def _update_preview(self) -> None:
        names = self.new_names()
        self.preview.setText(names[0] + (" ..." if len(names) > 1 else ""))
