"""Export-Optionen: smpl-/cue-Chunks für DAWs mitschreiben?"""

from __future__ import annotations

from PySide6.QtWidgets import (
    QCheckBox, QDialog, QDialogButtonBox, QVBoxLayout,
)

from ...core.wav_export import ExportOptions


class ExportOptionsDialog(QDialog):
    def __init__(self, opts: ExportOptions, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Export-Optionen")
        self.opts = opts
        layout = QVBoxLayout(self)
        self.smpl = QCheckBox("Loop-Punkte als 'smpl'-Chunk exportieren")
        self.smpl.setChecked(opts.with_smpl)
        layout.addWidget(self.smpl)
        self.cue = QCheckBox("Slices als 'cue '-Punkte exportieren")
        self.cue.setChecked(opts.with_cue)
        layout.addWidget(self.cue)
        buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def accept(self) -> None:
        self.opts.with_smpl = self.smpl.isChecked()
        self.opts.with_cue = self.cue.isChecked()
        super().accept()
