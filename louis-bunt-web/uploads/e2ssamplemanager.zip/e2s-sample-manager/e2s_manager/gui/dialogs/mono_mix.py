"""Stereo->Mono-Dialog mit Pan-Regler (wie im Original)."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog, QDialogButtonBox, QHBoxLayout, QLabel, QSlider, QVBoxLayout,
)


class MonoMixDialog(QDialog):
    def __init__(self, sample_name: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Stereo zu Mono")
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(
            f"'{sample_name}' wird zu Mono konvertiert.\n"
            "Mischverhältnis der Kanäle wählen:"
        ))
        row = QHBoxLayout()
        row.addWidget(QLabel("L"))
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(-100, 100)
        self.slider.setValue(0)
        self.slider.setTickPosition(QSlider.TicksBelow)
        self.slider.setTickInterval(50)
        row.addWidget(self.slider)
        row.addWidget(QLabel("R"))
        layout.addLayout(row)
        buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    @property
    def mix(self) -> float:
        return self.slider.value() / 100.0
