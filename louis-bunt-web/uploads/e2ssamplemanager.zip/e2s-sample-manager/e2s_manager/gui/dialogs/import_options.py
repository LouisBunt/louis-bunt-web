"""Import-Optionen (entspricht dem Import-Options-Dialog des Originals,
erweitert um Auto-Trim von Stille)."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox,
    QFormLayout, QHBoxLayout, QSlider, QSpinBox, QVBoxLayout,
)

from ...core.esli import OSC_CATEGORY_NAMES
from ...core.wav_import import ImportOptions


class ImportOptionsDialog(QDialog):
    def __init__(self, opts: ImportOptions, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Import-Optionen")
        self.opts = opts

        form = QFormLayout()

        self.cat_box = QComboBox()
        for name in OSC_CATEGORY_NAMES.values():
            self.cat_box.addItem(name)
        self.cat_box.setCurrentText(opts.osc_cat)
        self.cat_force = QCheckBox("erzwingen")
        self.cat_force.setChecked(opts.force_osc_cat)
        row = QHBoxLayout()
        row.addWidget(self.cat_box)
        row.addWidget(self.cat_force)
        form.addRow("Standard-Kategorie:", row)

        self.loop_box = QComboBox()
        self.loop_box.addItems(["One-Shot", "Loop"])
        self.loop_box.setCurrentIndex(opts.loop_type)
        self.loop_force = QCheckBox("erzwingen")
        self.loop_force.setChecked(opts.force_loop_type)
        row = QHBoxLayout()
        row.addWidget(self.loop_box)
        row.addWidget(self.loop_force)
        form.addRow("Abspielart:", row)

        self.db12 = QCheckBox("+12 dB Play Level")
        self.db12.setChecked(opts.plus_12_db)
        self.db12_force = QCheckBox("erzwingen")
        self.db12_force.setChecked(opts.force_plus_12_db)
        row = QHBoxLayout()
        row.addWidget(self.db12)
        row.addWidget(self.db12_force)
        form.addRow("", row)

        self.num_from = QSpinBox()
        self.num_from.setRange(19, 999)
        self.num_from.setValue(opts.smp_num_from)
        form.addRow("Freie Nummer suchen ab #:", self.num_from)

        self.force_mono = QCheckBox("Stereo automatisch zu Mono wandeln")
        self.force_mono.setChecked(opts.force_mono)
        form.addRow(self.force_mono)

        self.mix_slider = QSlider(Qt.Horizontal)
        self.mix_slider.setRange(-100, 100)
        self.mix_slider.setValue(int(opts.mono_mix * 100))
        form.addRow("Mono-Mix (L ... R):", self.mix_slider)

        self.auto_trim = QCheckBox("Stille am Anfang/Ende abschneiden")
        self.auto_trim.setChecked(opts.auto_trim_silence)
        form.addRow(self.auto_trim)

        self.trim_db = QDoubleSpinBox()
        self.trim_db.setRange(-96.0, -20.0)
        self.trim_db.setValue(opts.trim_threshold_db)
        self.trim_db.setSuffix(" dB")
        form.addRow("Stille-Schwelle:", self.trim_db)

        buttons = QDialogButtonBox(
            QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(buttons)

    def accept(self) -> None:
        o = self.opts
        o.osc_cat = self.cat_box.currentText()
        o.force_osc_cat = self.cat_force.isChecked()
        o.loop_type = self.loop_box.currentIndex()
        o.force_loop_type = self.loop_force.isChecked()
        o.plus_12_db = self.db12.isChecked()
        o.force_plus_12_db = self.db12_force.isChecked()
        o.smp_num_from = self.num_from.value()
        o.force_mono = self.force_mono.isChecked()
        o.mono_mix = self.mix_slider.value() / 100.0
        o.auto_trim_silence = self.auto_trim.isChecked()
        o.trim_threshold_db = self.trim_db.value()
        super().accept()
