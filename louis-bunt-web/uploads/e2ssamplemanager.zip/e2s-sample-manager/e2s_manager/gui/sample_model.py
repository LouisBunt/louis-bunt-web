"""Tabellen-Model und Filter-Proxy für die Sample-Liste."""

from __future__ import annotations

from PySide6.QtCore import (
    QAbstractTableModel, QModelIndex, QSortFilterProxyModel, Qt,
)
from PySide6.QtGui import QBrush, QColor

from ..core.esli import OSC_CATEGORY_IDS
from ..core.library import is_valid_num
from .commands import EsliFieldCommand, RenumberCommand
from .document import Document

COL_NUM = 0
COL_NAME = 1
COL_CAT = 2
COL_ONESHOT = 3
COL_12DB = 4
COL_TUNE = 5
COL_FREQ = 6
COL_TIME = 7
COL_STEREO = 8
COL_SIZE = 9
NUM_COLS = 10

HEADERS = ["#Num", "Name", "Kategorie", "1-Shot", "+12dB", "Tune",
           "Freq (Hz)", "Länge (s)", "Stereo", "Größe"]


class SampleTableModel(QAbstractTableModel):
    def __init__(self, doc: Document, parent=None):
        super().__init__(parent)
        self.doc = doc
        doc.structure_changed.connect(self._on_structure_changed)
        doc.sample_changed.connect(self._on_sample_changed)

    # --- Qt-Grundgerüst ---

    def rowCount(self, parent=QModelIndex()) -> int:
        return 0 if parent.isValid() else len(self.doc.library.samples)

    def columnCount(self, parent=QModelIndex()) -> int:
        return NUM_COLS

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            return HEADERS[section]
        return None

    def sample_at(self, row: int):
        return self.doc.library.samples[row]

    def _on_structure_changed(self) -> None:
        self.beginResetModel()
        self.endResetModel()

    def _on_sample_changed(self, row: int) -> None:
        self.dataChanged.emit(
            self.index(row, 0), self.index(row, NUM_COLS - 1)
        )

    # --- Anzeige ---

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        sample = self.sample_at(index.row())
        esli = sample.esli
        col = index.column()

        if role in (Qt.DisplayRole, Qt.EditRole):
            if col == COL_NUM:
                return esli.osc_num
            if col == COL_NAME:
                return esli.name
            if col == COL_CAT:
                return esli.category_name
            if col == COL_TUNE:
                return esli.sample_tune
            if col == COL_FREQ:
                return esli.sampling_freq
            if col == COL_TIME:
                return f"{sample.duration_seconds:.3f}"
            if col == COL_SIZE:
                return esli.wav_data_size
        elif role == Qt.CheckStateRole:
            if col == COL_ONESHOT:
                return Qt.Checked if esli.one_shot else Qt.Unchecked
            if col == COL_12DB:
                return Qt.Checked if esli.play_level_12db else Qt.Unchecked
            if col == COL_STEREO:
                return Qt.Checked if esli.is_stereo else Qt.Unchecked
        elif role == Qt.TextAlignmentRole:
            if col in (COL_NUM, COL_TUNE, COL_FREQ, COL_TIME, COL_SIZE):
                return int(Qt.AlignRight | Qt.AlignVCenter)
        elif role == Qt.ForegroundRole:
            if col == COL_NUM and esli.osc_0index < 500:
                # Factory-Bereich dezent markieren
                return QBrush(QColor(140, 140, 160))
        return None

    def flags(self, index):
        base = Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsDragEnabled
        col = index.column()
        if col in (COL_NUM, COL_NAME, COL_CAT, COL_TUNE, COL_FREQ):
            return base | Qt.ItemIsEditable
        if col in (COL_ONESHOT, COL_12DB):
            return base | Qt.ItemIsUserCheckable
        if col == COL_STEREO:
            sample = self.sample_at(index.row())
            if sample.esli.is_stereo:
                # Haken entfernen = Mono-Konvertierung (macht das Fenster)
                return base | Qt.ItemIsUserCheckable
            return base
        return base

    # --- Bearbeitung -> Undo-Commands ---

    def setData(self, index, value, role=Qt.EditRole) -> bool:
        if not index.isValid():
            return False
        sample = self.sample_at(index.row())
        esli = sample.esli
        col = index.column()
        stack = self.doc.undo_stack

        if role == Qt.CheckStateRole:
            checked = Qt.CheckState(value) == Qt.Checked
            if col == COL_ONESHOT:
                from .commands import SetLoopPointsCommand
                if checked:
                    stack.push(SetLoopPointsCommand(
                        self.doc, sample, esli.start_point_address,
                        esli.end_offset, esli.end_offset, True,
                        f"1-Shot für '{esli.name}'",
                    ))
                else:
                    stack.push(SetLoopPointsCommand(
                        self.doc, sample, esli.start_point_address,
                        esli.loop_start_offset, esli.end_offset, False,
                        f"Loop für '{esli.name}'",
                    ))
                return True
            if col == COL_12DB:
                stack.push(EsliFieldCommand(
                    self.doc, sample, "play_level_12db", checked,
                    f"+12dB {'an' if checked else 'aus'} für '{esli.name}'",
                ))
                return True
            return False

        if role != Qt.EditRole:
            return False

        if col == COL_NAME:
            new_name = str(value)
            if new_name == esli.name:
                return False
            stack.push(EsliFieldCommand(
                self.doc, sample, "name", new_name,
                f"Umbenennen in '{new_name}'",
            ))
            return True
        if col == COL_CAT:
            cat_id = OSC_CATEGORY_IDS.get(str(value))
            if cat_id is None or cat_id == esli.osc_category:
                return False
            stack.push(EsliFieldCommand(
                self.doc, sample, "osc_category", cat_id,
                f"Kategorie '{value}' für '{esli.name}'",
            ))
            return True
        if col == COL_NUM:
            try:
                num = int(value)
            except (TypeError, ValueError):
                return False
            if num == esli.osc_num or not is_valid_num(num):
                return False
            changes = self.doc.plan_renumber(sample, num)
            if not changes:
                return False
            stack.push(RenumberCommand(
                self.doc, changes, f"'{esli.name}' nach #{num}",
            ))
            return True
        if col == COL_TUNE:
            try:
                tune = max(-64, min(63, int(value)))
            except (TypeError, ValueError):
                return False
            if tune == esli.sample_tune:
                return False
            stack.push(EsliFieldCommand(
                self.doc, sample, "sample_tune", tune,
                f"Tune {tune:+d} für '{esli.name}'",
            ))
            return True
        if col == COL_FREQ:
            try:
                freq = max(1, min(192000, int(value)))
            except (TypeError, ValueError):
                return False
            if freq == esli.sampling_freq:
                return False
            stack.push(EsliFieldCommand(
                self.doc, sample, "sampling_freq", freq,
                f"Frequenz {freq} Hz für '{esli.name}'",
            ))
            return True
        return False


class SampleFilterProxy(QSortFilterProxyModel):
    """Suche im Namen + Kategorie-Filter, Sortierung über Spaltenköpfe."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.search_text = ""
        self.category_filter: int | None = None
        self.setSortRole(Qt.EditRole)

    def set_search(self, text: str) -> None:
        self.search_text = text.lower()
        self.invalidateRowsFilter()

    def set_category(self, cat_id: int | None) -> None:
        self.category_filter = cat_id
        self.invalidateRowsFilter()

    def filterAcceptsRow(self, source_row, source_parent) -> bool:
        sample = self.sourceModel().sample_at(source_row)
        esli = sample.esli
        if self.category_filter is not None:
            if esli.osc_category != self.category_filter:
                return False
        if self.search_text:
            hay = f"{esli.osc_num:03d} {esli.name}".lower()
            if self.search_text not in hay:
                return False
        return True

    def lessThan(self, left, right) -> bool:
        col = left.column()
        model = self.sourceModel()
        ls = model.sample_at(left.row())
        rs = model.sample_at(right.row())
        if col == COL_NAME:
            return ls.esli.name.lower() < rs.esli.name.lower()
        if col == COL_CAT:
            return ls.esli.osc_category < rs.esli.osc_category
        if col == COL_TIME:
            return ls.duration_seconds < rs.duration_seconds
        if col == COL_SIZE:
            return ls.esli.wav_data_size < rs.esli.wav_data_size
        return ls.esli.osc_0index < rs.esli.osc_0index
