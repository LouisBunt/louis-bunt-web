"""Hell/Dunkel-Design für die Oberfläche.

Der Waveform-/Slice-Editor ist ohnehin dunkel; der Dark Mode zieht das
auf die ganze App durch. Umschaltbar über das Ansicht-Menü, die Auswahl
wird per QSettings dauerhaft gemerkt.
"""

from __future__ import annotations

from PySide6.QtGui import QColor, QPalette
from PySide6.QtWidgets import QApplication

DARK = "dark"
LIGHT = "light"

# Zusätzliches Feintuning per Stylesheet (Palette allein deckt nicht alles ab)
_DARK_STYLESHEET = """
QToolTip {
    color: #e6e6e6;
    background-color: #2a2d35;
    border: 1px solid #44474f;
}
QTableView {
    gridline-color: #3a3d45;
    selection-background-color: #3d5a80;
    selection-color: #ffffff;
    alternate-background-color: #262930;
}
QHeaderView::section {
    background-color: #2a2d35;
    color: #d8d8d8;
    border: 0px;
    border-right: 1px solid #3a3d45;
    border-bottom: 1px solid #3a3d45;
    padding: 4px;
}
QProgressBar {
    background-color: #262930;
    border: 1px solid #3a3d45;
    border-radius: 3px;
}
QLineEdit, QSpinBox, QDoubleSpinBox, QComboBox {
    background-color: #262930;
    border: 1px solid #44474f;
    border-radius: 3px;
    padding: 2px 4px;
}
QPushButton {
    background-color: #2f333c;
    border: 1px solid #44474f;
    border-radius: 3px;
    padding: 4px 10px;
}
QPushButton:hover { background-color: #3a3f4a; }
QPushButton:pressed { background-color: #454b58; }
QPushButton:disabled { color: #6a6d75; }
QMenu, QMenuBar { background-color: #24272e; }
QMenu::item:selected, QMenuBar::item:selected { background-color: #3d5a80; }
"""


def _dark_palette() -> QPalette:
    p = QPalette()
    window = QColor(30, 33, 40)
    base = QColor(24, 26, 32)
    text = QColor(222, 224, 228)
    disabled = QColor(120, 123, 130)
    highlight = QColor(61, 90, 128)

    p.setColor(QPalette.Window, window)
    p.setColor(QPalette.WindowText, text)
    p.setColor(QPalette.Base, base)
    p.setColor(QPalette.AlternateBase, QColor(38, 41, 48))
    p.setColor(QPalette.ToolTipBase, QColor(42, 45, 53))
    p.setColor(QPalette.ToolTipText, text)
    p.setColor(QPalette.Text, text)
    p.setColor(QPalette.Button, QColor(47, 51, 60))
    p.setColor(QPalette.ButtonText, text)
    p.setColor(QPalette.BrightText, QColor(255, 90, 90))
    p.setColor(QPalette.Link, QColor(110, 170, 240))
    p.setColor(QPalette.Highlight, highlight)
    p.setColor(QPalette.HighlightedText, QColor(255, 255, 255))
    p.setColor(QPalette.PlaceholderText, disabled)

    for group in (QPalette.Disabled,):
        p.setColor(group, QPalette.WindowText, disabled)
        p.setColor(group, QPalette.Text, disabled)
        p.setColor(group, QPalette.ButtonText, disabled)
    return p


def apply_theme(app: QApplication, theme: str) -> None:
    """Design auf die laufende Anwendung anwenden."""
    if theme == DARK:
        app.setStyle("Fusion")
        app.setPalette(_dark_palette())
        app.setStyleSheet(_DARK_STYLESHEET)
    else:
        app.setStyle("Fusion")
        app.setPalette(app.style().standardPalette())
        app.setStyleSheet("")
