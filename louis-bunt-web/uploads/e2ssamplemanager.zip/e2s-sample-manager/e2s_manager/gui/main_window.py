"""Das Hauptfenster des E2S Sample Managers."""

from __future__ import annotations

import os

from PySide6.QtCore import QSettings, Qt
from PySide6.QtGui import QAction, QKeySequence
from PySide6.QtWidgets import (
    QComboBox, QFileDialog, QHBoxLayout, QInputDialog, QLabel, QLineEdit,
    QMainWindow, QMenu, QMessageBox, QProgressBar, QPushButton, QToolBar,
    QVBoxLayout, QWidget,
)

from .. import APP_NAME, __version__
from ..audio.player import Player
from ..backup import backup_file
from ..core import dsp
from ..core.esli import OSC_CATEGORY_NAMES
from ..core.library import (
    Library, LibraryError, MAX_WAV_DATA_SIZE, NoFreeSlot, is_valid_num,
)
from ..core.sample import E2sSample
from ..core.wav_export import ExportOptions, default_filename, export_sample
from ..core.wav_import import ImportOptions, from_wav
from ..sdcard import find_sample_all_paths
from .commands import (
    AddSamplesCommand, DeleteSamplesCommand, EsliFieldCommand,
    RenumberCommand, ReplaceSampleCommand, TransformSampleCommand,
)
from .dialogs.batch_rename import BatchRenameDialog
from .dialogs.export_options import ExportOptionsDialog
from .dialogs.import_options import ImportOptionsDialog
from .dialogs.mono_mix import MonoMixDialog
from .document import Document
from .sample_model import (
    COL_STEREO, SampleFilterProxy, SampleTableModel,
)
from .sample_table import LIBRARY_EXTENSIONS, SampleTableView
from .slice_editor import SliceEditorDialog
from .theme import DARK, LIGHT, apply_theme

ALL_FILTER = "Electribe Sample-Library (*.all);;Alle Dateien (*)"
WAV_FILTER = "WAV-Dateien (*.wav *.wave);;Alle Dateien (*)"


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.doc = Document(self)
        self.player = Player()
        self.import_opts = ImportOptions()
        self.export_opts = ExportOptions()

        self.model = SampleTableModel(self.doc, self)
        self.proxy = SampleFilterProxy(self)
        self.proxy.setSourceModel(self.model)

        self._build_ui()
        self._build_actions()
        self._connect()
        self._update_title()
        self._update_memory_bar()
        self.resize(1100, 720)

    # ------------------------------------------------------------- UI-Aufbau

    def _build_ui(self) -> None:
        central = QWidget()
        layout = QVBoxLayout(central)

        # Suche + Filter
        filter_row = QHBoxLayout()
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Suchen (Name oder #Nummer) ...")
        self.search_edit.setClearButtonEnabled(True)
        filter_row.addWidget(self.search_edit, stretch=2)
        self.category_box = QComboBox()
        self.category_box.addItem("Alle Kategorien", None)
        for cat_id, name in OSC_CATEGORY_NAMES.items():
            self.category_box.addItem(name, cat_id)
        filter_row.addWidget(self.category_box, stretch=1)
        self.stop_button = QPushButton("⏹ Stop")
        self.stop_button.setToolTip("Wiedergabe stoppen")
        filter_row.addWidget(self.stop_button)
        layout.addLayout(filter_row)

        self.table = SampleTableView()
        self.table.setModel(self.proxy)
        self.table.setContextMenuPolicy(Qt.CustomContextMenu)
        from PySide6.QtWidgets import QHeaderView
        from .sample_model import COL_NAME
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(COL_NAME, QHeaderView.Stretch)
        layout.addWidget(self.table)

        # Speicheranzeige
        mem_row = QHBoxLayout()
        self.memory_label = QLabel()
        mem_row.addWidget(self.memory_label)
        self.memory_bar = QProgressBar()
        self.memory_bar.setMaximum(1000)
        self.memory_bar.setTextVisible(False)
        mem_row.addWidget(self.memory_bar, stretch=1)
        layout.addLayout(mem_row)

        self.setCentralWidget(central)
        self.statusBar().showMessage("Bereit")

    def _build_actions(self) -> None:
        toolbar = QToolBar("Datei")
        toolbar.setMovable(False)
        self.addToolBar(toolbar)

        def add(menu, text, slot, shortcut=None, toolbar_too=True):
            action = QAction(text, self)
            if shortcut:
                action.setShortcut(QKeySequence(shortcut))
            action.triggered.connect(slot)
            menu.addAction(action)
            if toolbar_too:
                toolbar.addAction(action)
            return action

        file_menu = self.menuBar().addMenu("&Datei")
        add(file_menu, "Neu", self.action_new, "Ctrl+N", False)
        add(file_menu, "Öffnen ...", self.action_open, "Ctrl+O")
        self.sd_action = add(
            file_menu, "SD-Karte öffnen", self.action_open_sd, None
        )
        file_menu.addSeparator()
        add(file_menu, "Speichern", self.action_save, "Ctrl+S")
        add(file_menu, "Speichern unter ...", self.action_save_as,
            "Ctrl+Shift+S", False)
        file_menu.addSeparator()
        add(file_menu, "Beenden", self.close, "Ctrl+Q", False)

        edit_menu = self.menuBar().addMenu("&Bearbeiten")
        undo = self.doc.undo_stack.createUndoAction(self, "Rückgängig")
        undo.setShortcut(QKeySequence.Undo)
        edit_menu.addAction(undo)
        redo = self.doc.undo_stack.createRedoAction(self, "Wiederholen")
        redo.setShortcut(QKeySequence.Redo)
        edit_menu.addAction(redo)
        edit_menu.addSeparator()
        add(edit_menu, "Löschen", self.action_delete, "Del", False)

        view_menu = self.menuBar().addMenu("&Ansicht")
        self.dark_mode_action = QAction("Dark Mode", self)
        self.dark_mode_action.setCheckable(True)
        self.dark_mode_action.setShortcut(QKeySequence("Ctrl+D"))
        self.dark_mode_action.setChecked(self._settings_theme() == DARK)
        self.dark_mode_action.toggled.connect(self._toggle_dark_mode)
        view_menu.addAction(self.dark_mode_action)

        import_menu = self.menuBar().addMenu("&Import")
        toolbar.addSeparator()
        add(import_menu, "WAV importieren ...", self.action_import_wav, "Ctrl+I")
        add(import_menu, "e2sSample.all importieren ...",
            self.action_import_all, None, False)
        add(import_menu, "Import-Optionen ...", self.action_import_options,
            None, False)

        export_menu = self.menuBar().addMenu("&Export")
        add(export_menu, "Auswahl als WAV exportieren ...",
            self.action_export_selected, "Ctrl+E", False)
        add(export_menu, "Alle als WAV exportieren ...",
            self.action_export_all, None, False)
        add(export_menu, "Export-Optionen ...", self.action_export_options,
            None, False)

        help_menu = self.menuBar().addMenu("&Hilfe")
        add(help_menu, "Über ...", self.action_about, None, False)

    def _connect(self) -> None:
        self.search_edit.textChanged.connect(self.proxy.set_search)
        self.category_box.currentIndexChanged.connect(
            lambda _: self.proxy.set_category(self.category_box.currentData())
        )
        self.stop_button.clicked.connect(self.player.stop)
        self.table.customContextMenuRequested.connect(self._context_menu)
        self.table.doubleClicked.connect(self._maybe_stereo_toggle)
        self.table.files_dropped.connect(self._import_paths)
        self.table.rows_move_requested.connect(self._move_rows)
        self.doc.structure_changed.connect(self._update_memory_bar)
        self.doc.sample_changed.connect(lambda _: self._update_memory_bar())
        self.doc.path_changed.connect(self._update_title)
        self.doc.undo_stack.cleanChanged.connect(
            lambda _: self._update_title()
        )
        self.model.dataChanged.connect(lambda *a: self._update_memory_bar())

    # ------------------------------------------------------------ Statuszeile

    def _update_title(self) -> None:
        name = os.path.basename(self.doc.path) if self.doc.path else "Neue Library"
        dirty = "*" if self.doc.dirty else ""
        self.setWindowTitle(f"{dirty}{name} - {APP_NAME}")

    def _update_memory_bar(self) -> None:
        used = self.doc.library.total_wav_size()
        ratio = used / MAX_WAV_DATA_SIZE
        self.memory_bar.setValue(min(1000, int(ratio * 1000)))
        mb_used = used / (1024 * 1024)
        mb_max = MAX_WAV_DATA_SIZE / (1024 * 1024)
        self.memory_label.setText(
            f"{len(self.doc.library)} Samples | "
            f"{mb_used:.1f} / {mb_max:.1f} MB"
        )
        self.memory_bar.setStyleSheet(
            "QProgressBar::chunk { background-color: %s; }"
            % ("#cc3333" if ratio > 1.0 else "#44aa66")
        )
        if ratio > 1.0:
            self.statusBar().showMessage(
                "Achtung: Speicherlimit der Electribe überschritten!"
            )

    # -------------------------------------------------------------- Auswahl

    def _selected_samples(self) -> list[E2sSample]:
        return [
            self.model.sample_at(row)
            for row in self.table.selected_source_rows()
        ]

    def _current_sample(self) -> E2sSample | None:
        samples = self._selected_samples()
        return samples[0] if samples else None

    # ------------------------------------------------------- Datei-Aktionen

    def _confirm_discard(self) -> bool:
        if not self.doc.dirty:
            return True
        answer = QMessageBox.question(
            self, "Ungespeicherte Änderungen",
            "Die Library enthält ungespeicherte Änderungen. Verwerfen?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No,
        )
        return answer == QMessageBox.Yes

    def action_new(self) -> None:
        if self._confirm_discard():
            self.player.stop()
            self.doc.new()

    def action_open(self, checked=False, path: str | None = None) -> None:
        if not self._confirm_discard():
            return
        if not path:
            path, _ = QFileDialog.getOpenFileName(
                self, "Library öffnen", "", ALL_FILTER
            )
        if not path:
            return
        self.player.stop()
        try:
            errors = self.doc.open(path)
        except (LibraryError, OSError) as exc:
            QMessageBox.critical(self, "Fehler beim Öffnen", str(exc))
            return
        if errors:
            QMessageBox.warning(
                self, "Defekte Samples übersprungen",
                "Beim Laden wurden Probleme gefunden:\n\n" + "\n".join(errors),
            )
        self.statusBar().showMessage(
            f"{len(self.doc.library)} Samples geladen", 5000
        )

    def action_open_sd(self) -> None:
        paths = find_sample_all_paths()
        if not paths:
            QMessageBox.information(
                self, "Keine SD-Karte gefunden",
                "Keine eingehängte SD-Karte mit "
                "KORG/electribe sampler/Sample/e2sSample.all gefunden.\n"
                "Nutze 'Öffnen ...', um die Datei manuell zu wählen.",
            )
            return
        if len(paths) == 1:
            self.action_open(path=paths[0])
            return
        choice, ok = QInputDialog.getItem(
            self, "SD-Karte wählen", "Gefundene Libraries:", paths, 0, False
        )
        if ok and choice:
            self.action_open(path=choice)

    def _pre_save_checks(self) -> bool:
        if self.doc.library.exceeds_memory():
            answer = QMessageBox.question(
                self, "Speicherlimit überschritten",
                "Die Library ist größer als der Sample-Speicher der "
                "Electribe - sie wird am Gerät nicht vollständig geladen.\n"
                "Trotzdem speichern?",
            )
            if answer != QMessageBox.Yes:
                return False
        return True

    def action_save(self) -> None:
        if not self.doc.path:
            self.action_save_as()
            return
        if not self._pre_save_checks():
            return
        try:
            backup = backup_file(self.doc.path)
            self.doc.save()
        except (LibraryError, OSError) as exc:
            QMessageBox.critical(self, "Fehler beim Speichern", str(exc))
            return
        message = f"Gespeichert: {self.doc.path}"
        if backup:
            message += f" (Backup: {os.path.basename(backup)})"
        self.statusBar().showMessage(message, 8000)

    def action_save_as(self) -> None:
        if not self._pre_save_checks():
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Library speichern", self.doc.path or "e2sSample.all",
            ALL_FILTER,
        )
        if not path:
            return
        if not path.lower().endswith(".all"):
            path += ".all"
        try:
            backup_file(path)
            self.doc.save(path)
        except (LibraryError, OSError) as exc:
            QMessageBox.critical(self, "Fehler beim Speichern", str(exc))
            return
        self.statusBar().showMessage(f"Gespeichert: {path}", 8000)

    def closeEvent(self, event) -> None:
        if self._confirm_discard():
            self.player.stop()
            event.accept()
        else:
            event.ignore()

    # ------------------------------------------------------------- Import

    def action_import_wav(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(
            self, "WAV-Samples importieren", "", WAV_FILTER
        )
        if paths:
            self._import_paths(paths)

    def action_import_all(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, "Samples aus Library importieren", "", ALL_FILTER
        )
        if path:
            self._import_paths([path])

    def action_import_options(self) -> None:
        ImportOptionsDialog(self.import_opts, self).exec()

    def _import_paths(self, paths: list[str]) -> None:
        imported: list[E2sSample] = []
        problems: list[str] = []
        # Nummern fortlaufend ab der Option vergeben, ohne Konflikte
        search_from = self.import_opts.smp_num_from

        def next_free() -> int:
            lib = self.doc.library
            num = search_from
            while True:
                candidate = lib.first_free_num(num)
                if candidate not in {s.esli.osc_num for s in imported}:
                    return candidate
                num = candidate + 1

        for path in paths:
            ext = os.path.splitext(path)[1].lower()
            try:
                if ext in LIBRARY_EXTENSIONS:
                    other = Library.load(path)
                    problems.extend(other.load_errors)
                    for sample in other:
                        sample.esli.osc_num = next_free()
                        imported.append(sample)
                else:
                    result = from_wav(path, self.import_opts)
                    result.sample.esli.osc_num = next_free()
                    imported.append(result.sample)
            except NoFreeSlot:
                problems.append("Kein freier Sample-Platz mehr - Rest übersprungen")
                break
            except Exception as exc:
                problems.append(f"{os.path.basename(path)}: {exc}")

        if imported:
            self.doc.undo_stack.push(AddSamplesCommand(
                self.doc, imported,
                f"{len(imported)} Sample(s) importieren",
            ))
            self.statusBar().showMessage(
                f"{len(imported)} Sample(s) importiert", 5000
            )
        if problems:
            QMessageBox.warning(
                self, "Import-Probleme", "\n".join(problems[:20])
            )

    # ------------------------------------------------------------- Export

    def action_export_options(self) -> None:
        ExportOptionsDialog(self.export_opts, self).exec()

    def action_export_selected(self) -> None:
        samples = self._selected_samples()
        if not samples:
            return
        if len(samples) == 1:
            sample = samples[0]
            path, _ = QFileDialog.getSaveFileName(
                self, "Sample exportieren", default_filename(sample),
                WAV_FILTER,
            )
            if path:
                self._export([(sample, path)])
        else:
            directory = QFileDialog.getExistingDirectory(
                self, "Zielordner für Export"
            )
            if directory:
                self._export([
                    (s, os.path.join(directory, default_filename(s)))
                    for s in samples
                ])

    def action_export_all(self) -> None:
        if not len(self.doc.library):
            return
        directory = QFileDialog.getExistingDirectory(
            self, "Zielordner für Export"
        )
        if directory:
            self._export([
                (s, os.path.join(directory, default_filename(s)))
                for s in self.doc.library
            ])

    def _export(self, jobs: list[tuple[E2sSample, str]]) -> None:
        errors = []
        for sample, path in jobs:
            try:
                export_sample(sample, path, self.export_opts)
            except OSError as exc:
                errors.append(f"{os.path.basename(path)}: {exc}")
        if errors:
            QMessageBox.warning(self, "Export-Probleme", "\n".join(errors[:20]))
        else:
            self.statusBar().showMessage(
                f"{len(jobs)} Datei(en) exportiert", 5000
            )

    # ----------------------------------------------------- Sample-Aktionen

    def action_delete(self) -> None:
        samples = self._selected_samples()
        if not samples:
            return
        self.player.stop()
        self.doc.undo_stack.push(DeleteSamplesCommand(
            self.doc, samples, f"{len(samples)} Sample(s) löschen",
        ))

    def action_play(self) -> None:
        sample = self._current_sample()
        if sample:
            self.player.play_sample(sample)

    def action_edit(self) -> None:
        sample = self._current_sample()
        if sample:
            SliceEditorDialog(self.doc, sample, self.player, self).exec()

    def action_replace(self) -> None:
        sample = self._current_sample()
        if not sample:
            return
        path, _ = QFileDialog.getOpenFileName(
            self, f"Ersatz für #{sample.esli.osc_num:03d} wählen", "",
            WAV_FILTER,
        )
        if not path:
            return
        try:
            result = from_wav(path, self.import_opts)
        except Exception as exc:
            QMessageBox.critical(self, "Import-Fehler", str(exc))
            return
        self.doc.undo_stack.push(ReplaceSampleCommand(
            self.doc, sample, result.sample,
            f"#{sample.esli.osc_num:03d} ersetzen",
        ))

    def action_move_to(self) -> None:
        sample = self._current_sample()
        if not sample:
            return
        num, ok = QInputDialog.getInt(
            self, "Verschieben", "Neue Sample-Nummer (19-421, 501-999):",
            sample.esli.osc_num, 19, 999,
        )
        if not ok or num == sample.esli.osc_num:
            return
        if not is_valid_num(num):
            QMessageBox.warning(
                self, "Ungültige Nummer",
                "Die Nummern 422-500 sind auf der Electribe nicht nutzbar.",
            )
            return
        changes = self.doc.plan_renumber(sample, num)
        if changes is None:
            QMessageBox.warning(
                self, "Kein Platz",
                "In dieser Richtung ist nicht genug Platz zum Verschieben.",
            )
            return
        self.doc.undo_stack.push(RenumberCommand(
            self.doc, changes, f"'{sample.esli.name}' nach #{num}",
        ))

    def action_swap_with(self) -> None:
        sample = self._current_sample()
        if not sample:
            return
        others = [
            f"#{s.esli.osc_num:03d} {s.esli.name}"
            for s in self.doc.library if s is not sample
        ]
        if not others:
            return
        choice, ok = QInputDialog.getItem(
            self, "Tauschen", "Tauschen mit:", others, 0, False
        )
        if not ok or not choice:
            return
        num = int(choice.split()[0].lstrip("#"))
        other = self.doc.library.get_by_num(num)
        if other is None:
            return
        self.doc.undo_stack.push(RenumberCommand(
            self.doc,
            {sample: other.esli.osc_num, other: sample.esli.osc_num},
            f"#{sample.esli.osc_num:03d} und #{num:03d} tauschen",
        ))

    def action_move_free(self, direction: int) -> None:
        sample = self._current_sample()
        if not sample:
            return
        used = self.doc.library.used_nums()
        from ..core.library import next_valid_num
        num = next_valid_num(sample.esli.osc_num, direction)
        while num is not None and num in used:
            num = next_valid_num(num, direction)
        if num is None:
            self.statusBar().showMessage(
                "Kein freier Platz in dieser Richtung", 4000
            )
            return
        self.doc.undo_stack.push(RenumberCommand(
            self.doc, {sample: num},
            f"'{sample.esli.name}' nach #{num}",
        ))

    def _move_rows(self, rows: list[int], target_row: int) -> None:
        """Drag-Umsortierung: erstes gewähltes Sample an die Zielposition."""
        if not rows:
            return
        sample = self.model.sample_at(rows[0])
        target = self.model.sample_at(target_row)
        if sample is target:
            return
        changes = self.doc.plan_renumber(sample, target.esli.osc_num)
        if changes is None:
            self.statusBar().showMessage("Kein Platz zum Verschieben", 4000)
            return
        self.doc.undo_stack.push(RenumberCommand(
            self.doc, changes,
            f"'{sample.esli.name}' nach #{target.esli.osc_num}",
        ))

    def _maybe_stereo_toggle(self, proxy_index) -> None:
        """Doppelklick auf die Stereo-Spalte -> Mono-Konvertierung anbieten."""
        index = self.proxy.mapToSource(proxy_index)
        if index.column() != COL_STEREO:
            return
        sample = self.model.sample_at(index.row())
        if not sample.esli.is_stereo:
            return
        dialog = MonoMixDialog(sample.esli.name, self)
        if dialog.exec():
            self._convert_mono([sample], dialog.mix)

    def _convert_mono(self, samples: list[E2sSample], mix: float) -> None:
        for sample in samples:
            command = TransformSampleCommand(
                self.doc, sample, lambda s: dsp.to_mono(s, mix),
                f"'{sample.esli.name}' zu Mono",
            )
            if command.changed:
                self.doc.undo_stack.push(command)

    # ------------------------------------------------------- Batch-Aktionen

    def _batch_transform(self, samples, transform, label: str) -> None:
        self.doc.undo_stack.beginMacro(label)
        changed = 0
        for sample in samples:
            command = TransformSampleCommand(self.doc, sample, transform, label)
            if command.changed:
                self.doc.undo_stack.push(command)
                changed += 1
        self.doc.undo_stack.endMacro()
        self.statusBar().showMessage(
            f"{label}: {changed} von {len(samples)} Samples geändert", 5000
        )

    def action_batch_category(self, samples: list[E2sSample]) -> None:
        names = list(OSC_CATEGORY_NAMES.values())
        choice, ok = QInputDialog.getItem(
            self, "Kategorie setzen", "Neue Kategorie:", names, 17, False
        )
        if not ok:
            return
        from ..core.esli import OSC_CATEGORY_IDS
        cat_id = OSC_CATEGORY_IDS[choice]
        self.doc.undo_stack.beginMacro(f"Kategorie '{choice}' setzen")
        for sample in samples:
            if sample.esli.osc_category != cat_id:
                self.doc.undo_stack.push(EsliFieldCommand(
                    self.doc, sample, "osc_category", cat_id,
                    f"Kategorie '{choice}'",
                ))
        self.doc.undo_stack.endMacro()

    def action_batch_rename(self, samples: list[E2sSample]) -> None:
        dialog = BatchRenameDialog([s.esli.name for s in samples], self)
        if not dialog.exec():
            return
        new_names = dialog.new_names()
        self.doc.undo_stack.beginMacro(f"{len(samples)} Samples umbenennen")
        for sample, name in zip(samples, new_names):
            if sample.esli.name != name:
                self.doc.undo_stack.push(EsliFieldCommand(
                    self.doc, sample, "name", name, f"Umbenennen in '{name}'",
                ))
        self.doc.undo_stack.endMacro()

    def action_batch_mono(self, samples: list[E2sSample]) -> None:
        stereo = [s for s in samples if s.esli.is_stereo]
        if not stereo:
            self.statusBar().showMessage("Keine Stereo-Samples in der Auswahl", 4000)
            return
        dialog = MonoMixDialog(f"{len(stereo)} Samples", self)
        if dialog.exec():
            self.doc.undo_stack.beginMacro("Auto-Mono")
            self._convert_mono(stereo, dialog.mix)
            self.doc.undo_stack.endMacro()

    # ---------------------------------------------------------- Kontextmenü

    def _context_menu(self, pos) -> None:
        samples = self._selected_samples()
        menu = QMenu(self)
        if samples:
            single = len(samples) == 1
            if single:
                menu.addAction("▶ Anhören", self.action_play)
                menu.addAction("Bearbeiten (Punkte/Slices) ...", self.action_edit)
                menu.addAction("Ersetzen durch WAV ...", self.action_replace)
                menu.addSeparator()
                menu.addAction("Verschieben nach # ...", self.action_move_to)
                menu.addAction("Tauschen mit ...", self.action_swap_with)
                menu.addAction(
                    "Hoch zum nächsten freien Platz",
                    lambda: self.action_move_free(-1),
                )
                menu.addAction(
                    "Runter zum nächsten freien Platz",
                    lambda: self.action_move_free(1),
                )
                menu.addSeparator()
            label = "Auswahl" if not single else f"'{samples[0].esli.name}'"
            menu.addAction(f"{label} exportieren ...", self.action_export_selected)
            menu.addSeparator()
            menu.addAction(
                "Normalisieren",
                lambda: self._batch_transform(
                    samples, dsp.normalize, "Normalisieren"
                ),
            )
            menu.addAction(
                "Stille abschneiden (Auto-Trim)",
                lambda: self._batch_transform(
                    samples,
                    lambda s: dsp.trim_silence(
                        s, self.import_opts.trim_threshold_db
                    ),
                    "Auto-Trim",
                ),
            )
            menu.addAction(
                "Zu Mono konvertieren ...",
                lambda: self.action_batch_mono(samples),
            )
            if not single:
                menu.addAction(
                    "Umbenennen mit Muster ...",
                    lambda: self.action_batch_rename(samples),
                )
            menu.addAction(
                "Kategorie setzen ...",
                lambda: self.action_batch_category(samples),
            )
            menu.addSeparator()
            menu.addAction(f"{label} löschen", self.action_delete)
        else:
            menu.addAction("WAV importieren ...", self.action_import_wav)
        menu.exec(self.table.viewport().mapToGlobal(pos))

    # ------------------------------------------------------------- Design

    @staticmethod
    def _settings_theme() -> str:
        settings = QSettings("e2s-sample-manager", "e2s-sample-manager")
        return str(settings.value("theme", DARK))

    def _toggle_dark_mode(self, enabled: bool) -> None:
        theme = DARK if enabled else LIGHT
        QSettings("e2s-sample-manager", "e2s-sample-manager").setValue(
            "theme", theme
        )
        from PySide6.QtWidgets import QApplication
        apply_theme(QApplication.instance(), theme)

    # -------------------------------------------------------------- Sonstiges

    def action_about(self) -> None:
        QMessageBox.about(
            self, f"Über {APP_NAME}",
            f"<b>{APP_NAME}</b> v{__version__}<br><br>"
            "Sample-Library-Manager für die Korg Electribe 2 Sampler "
            "(e2sSample.all).<br><br>"
            "Formatlogik basiert auf Oe2sSLE von Jonathan Taquet "
            "(GPL-3).<br>"
            "Dieses Programm ist freie Software unter der GNU GPL v3.",
        )
