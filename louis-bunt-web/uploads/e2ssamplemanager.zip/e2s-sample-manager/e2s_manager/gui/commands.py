"""Undo-fähige Commands für alle Library-Mutationen.

Metadaten-Änderungen speichern Vorher/Nachher-Werte, audio-verändernde
Operationen (Trim, Mono, Normalisieren, Ersetzen) sichern einen
Byte-Snapshot des kompletten Samples - einfach und garantiert korrekt.
"""

from __future__ import annotations

import io
from typing import Callable

from PySide6.QtGui import QUndoCommand

from ..core.sample import E2sSample
from .document import Document


class EsliFieldCommand(QUndoCommand):
    """Ein einzelnes esli-Feld setzen (Name, Kategorie, Tune, Flags ...)."""

    def __init__(self, doc: Document, sample: E2sSample, attr: str,
                 value, text: str):
        super().__init__(text)
        self._doc = doc
        self._sample = sample
        self._attr = attr
        self._new = value
        self._old = getattr(sample.esli, attr)

    def redo(self) -> None:
        setattr(self._sample.esli, self._attr, self._new)
        self._doc.notify_sample_changed(self._sample)

    def undo(self) -> None:
        setattr(self._sample.esli, self._attr, self._old)
        self._doc.notify_sample_changed(self._sample)


class SetLoopPointsCommand(QUndoCommand):
    """Start/Loop/End-Punkte gemeinsam setzen (für Editor und One-Shot)."""

    def __init__(self, doc: Document, sample: E2sSample,
                 start: int, loop: int, end: int, one_shot: bool, text: str):
        super().__init__(text)
        self._doc = doc
        self._sample = sample
        esli = sample.esli
        self._old = (esli.start_point_address, esli.loop_start_offset,
                     esli.end_offset, esli.one_shot)
        self._new = (start, loop, end, one_shot)

    def _apply(self, values) -> None:
        esli = self._sample.esli
        (esli.start_point_address, esli.loop_start_offset,
         esli.end_offset, esli.one_shot) = values
        self._doc.notify_sample_changed(self._sample)

    def redo(self) -> None:
        self._apply(self._new)

    def undo(self) -> None:
        self._apply(self._old)


class RenumberCommand(QUndoCommand):
    """Nummern mehrerer Samples ändern (Verschieben/Tauschen/Schieben)."""

    def __init__(self, doc: Document, changes: dict[E2sSample, int], text: str):
        super().__init__(text)
        self._doc = doc
        self._new = dict(changes)
        self._old = {s: s.esli.osc_num for s in changes}

    def _apply(self, mapping: dict[E2sSample, int]) -> None:
        for sample, num in mapping.items():
            sample.esli.osc_num = num
        self._doc.library.sort()
        self._doc.notify_structure_changed()

    def redo(self) -> None:
        self._apply(self._new)

    def undo(self) -> None:
        self._apply(self._old)


class AddSamplesCommand(QUndoCommand):
    """Importierte Samples einfügen (Nummern sind bereits vergeben)."""

    def __init__(self, doc: Document, samples: list[E2sSample], text: str):
        super().__init__(text)
        self._doc = doc
        self._samples = list(samples)

    def redo(self) -> None:
        self._doc.library.samples.extend(self._samples)
        self._doc.library.sort()
        self._doc.notify_structure_changed()

    def undo(self) -> None:
        for sample in self._samples:
            self._doc.library.samples.remove(sample)
        self._doc.notify_structure_changed()


class DeleteSamplesCommand(QUndoCommand):
    def __init__(self, doc: Document, samples: list[E2sSample], text: str):
        super().__init__(text)
        self._doc = doc
        self._samples = list(samples)

    def redo(self) -> None:
        for sample in self._samples:
            self._doc.library.samples.remove(sample)
        self._doc.notify_structure_changed()

    def undo(self) -> None:
        self._doc.library.samples.extend(self._samples)
        self._doc.library.sort()
        self._doc.notify_structure_changed()


class ReplaceSampleCommand(QUndoCommand):
    """Sample durch ein anderes ersetzen (behält die Nummer)."""

    def __init__(self, doc: Document, old: E2sSample, new: E2sSample, text: str):
        super().__init__(text)
        self._doc = doc
        self._old = old
        self._new = new
        new.esli.osc_num = old.esli.osc_num

    def redo(self) -> None:
        samples = self._doc.library.samples
        samples[samples.index(self._old)] = self._new
        self._doc.notify_structure_changed()

    def undo(self) -> None:
        samples = self._doc.library.samples
        samples[samples.index(self._new)] = self._old
        self._doc.notify_structure_changed()


class TransformSampleCommand(QUndoCommand):
    """Audio-verändernde Operation mit Byte-Snapshot als Undo.

    transform bekommt das Sample und gibt True zurück, wenn es etwas
    geändert hat (dann wird der Command wirksam), sonst False.
    """

    def __init__(self, doc: Document, sample: E2sSample,
                 transform: Callable[[E2sSample], bool], text: str):
        super().__init__(text)
        self._doc = doc
        self._sample = sample
        self._before = sample.to_bytes()
        self.changed = bool(transform(sample))
        self._after = sample.to_bytes() if self.changed else self._before
        self._first_redo = True

    def _restore(self, raw: bytes) -> None:
        restored = E2sSample(io.BytesIO(raw))
        self._sample.chunks = restored.chunks
        self._doc.notify_sample_changed(self._sample)

    def redo(self) -> None:
        if self._first_redo:
            # Transformation lief schon im Konstruktor
            self._first_redo = False
            self._doc.notify_sample_changed(self._sample)
            return
        self._restore(self._after)

    def undo(self) -> None:
        self._restore(self._before)
