"""Waveform-Anzeige mit Zoom und ziehbaren Punkt-Markern.

QoL gegenüber dem Original: Mausrad-Zoom auf Cursorposition,
Nulldurchgang-Snapping beim Ziehen von Markern, vorberechnete
Peak-Darstellung (flüssig auch bei langen Samples).
"""

from __future__ import annotations

import numpy as np

from PySide6.QtCore import QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QPainter, QPen, QPolygonF
from PySide6.QtWidgets import QWidget

MARKER_COLORS = {
    "start": QColor(80, 200, 120),
    "loop": QColor(80, 140, 240),
    "end": QColor(240, 100, 100),
    "slice_first": QColor(240, 180, 60),
    "slice_last": QColor(200, 120, 240),
}
MARKER_LABELS = {
    "start": "Start",
    "loop": "Loop",
    "end": "End",
    "slice_first": "Slice-Anfang",
    "slice_last": "Slice-Ende",
}
GRAB_RADIUS_PX = 6


class WaveformWidget(QWidget):
    marker_moved = Signal(str, int)  # Markername, neuer Frame

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(160)
        self.setMouseTracking(True)
        self._frames = np.zeros((0, 1), dtype=np.int16)
        self._markers: dict[str, int] = {}
        self._view_start = 0.0  # erster sichtbarer Frame
        self._frames_per_px = 1.0
        self._drag_marker: str | None = None
        self._pan_anchor: tuple[float, float] | None = None
        self._user_zoomed = False
        self.snap_zero_crossing = True

    # --- Daten ---

    def set_frames(self, frames: np.ndarray) -> None:
        self._frames = frames if frames.size else np.zeros((0, 1), dtype=np.int16)
        self.zoom_fit()

    def set_markers(self, markers: dict[str, int]) -> None:
        self._markers = dict(markers)
        self.update()

    def num_frames(self) -> int:
        return len(self._frames)

    # --- Koordinaten ---

    def _x_to_frame(self, x: float) -> int:
        frame = int(self._view_start + x * self._frames_per_px)
        return max(0, min(self.num_frames() - 1, frame))

    def _frame_to_x(self, frame: float) -> float:
        return (frame - self._view_start) / self._frames_per_px

    def zoom_fit(self) -> None:
        self._view_start = 0.0
        width = max(1, self.width())
        self._frames_per_px = max(1e-6, self.num_frames() / width)
        self._user_zoomed = False
        self.update()

    # --- Interaktion ---

    def wheelEvent(self, event):
        if not self.num_frames():
            return
        self._user_zoomed = True
        pos_x = event.position().x()
        anchor_frame = self._view_start + pos_x * self._frames_per_px
        factor = 0.8 if event.angleDelta().y() > 0 else 1.25
        min_fpp = 0.05
        max_fpp = max(1e-6, self.num_frames() / max(1, self.width()))
        self._frames_per_px = min(max(self._frames_per_px * factor, min_fpp),
                                  max_fpp * 1.0 if max_fpp > min_fpp else min_fpp)
        self._view_start = anchor_frame - pos_x * self._frames_per_px
        self._clamp_view()
        self.update()

    def _clamp_view(self) -> None:
        visible = self.width() * self._frames_per_px
        self._view_start = max(0.0, min(self._view_start,
                                        max(0.0, self.num_frames() - visible)))

    def _marker_near(self, x: float) -> str | None:
        best, best_dist = None, GRAB_RADIUS_PX + 1
        for name, frame in self._markers.items():
            dist = abs(self._frame_to_x(frame) - x)
            if dist < best_dist:
                best, best_dist = name, dist
        return best

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            marker = self._marker_near(event.position().x())
            if marker is not None:
                self._drag_marker = marker
                return
            self._pan_anchor = (event.position().x(), self._view_start)

    def mouseMoveEvent(self, event):
        x = event.position().x()
        if self._drag_marker is not None:
            frame = self._x_to_frame(x)
            if self.snap_zero_crossing:
                frame = self._snap_to_zero(frame)
            self._markers[self._drag_marker] = frame
            self.marker_moved.emit(self._drag_marker, frame)
            self.update()
            return
        if self._pan_anchor is not None:
            anchor_x, anchor_start = self._pan_anchor
            self._view_start = anchor_start + (anchor_x - x) * self._frames_per_px
            self._clamp_view()
            self.update()
            return
        self.setCursor(
            Qt.SizeHorCursor if self._marker_near(x) else Qt.ArrowCursor
        )

    def mouseReleaseEvent(self, event):
        self._drag_marker = None
        self._pan_anchor = None

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if self._user_zoomed:
            self._clamp_view()
        else:
            # solange nicht manuell gezoomt wurde: ganzes Sample einpassen
            self.zoom_fit()

    def _snap_to_zero(self, frame: int, radius: int = 200) -> int:
        """Nächsten Nulldurchgang in der Umgebung suchen."""
        if not self.num_frames():
            return frame
        lo = max(0, frame - radius)
        hi = min(self.num_frames(), frame + radius)
        window = self._frames[lo:hi, 0].astype(np.int32)
        if len(window) < 2:
            return frame
        signs = np.signbit(window)
        crossings = np.flatnonzero(signs[:-1] != signs[1:])
        if crossings.size == 0:
            return frame
        best = crossings[np.argmin(np.abs(crossings + lo - frame))]
        return int(best + lo)

    # --- Zeichnen ---

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(24, 26, 32))
        width = self.width()
        height = self.height()
        mid = height / 2

        painter.setPen(QPen(QColor(60, 64, 72), 1))
        painter.drawLine(0, int(mid), width, int(mid))

        if self.num_frames():
            painter.setPen(QPen(QColor(120, 200, 170), 1))
            mono = self._frames[:, 0]
            scale = mid / 33000.0
            fpp = self._frames_per_px
            if fpp >= 2.0:
                # Peak-Darstellung: pro Pixel min/max
                for x in range(width):
                    lo_f = int(self._view_start + x * fpp)
                    hi_f = min(self.num_frames(), int(lo_f + fpp) + 1)
                    if lo_f >= self.num_frames() or lo_f < 0:
                        continue
                    seg = mono[lo_f:hi_f]
                    painter.drawLine(
                        QPointF(x, mid - float(seg.max()) * scale),
                        QPointF(x, mid - float(seg.min()) * scale),
                    )
            else:
                # Linien-Darstellung bei starkem Zoom
                first = max(0, int(self._view_start))
                last = min(self.num_frames(),
                           int(self._view_start + width * fpp) + 2)
                points = QPolygonF()
                for f in range(first, last):
                    points.append(QPointF(
                        self._frame_to_x(f), mid - float(mono[f]) * scale
                    ))
                painter.drawPolyline(points)

        # Marker
        for name, frame in self._markers.items():
            x = self._frame_to_x(frame)
            if -4 <= x <= width + 4:
                color = MARKER_COLORS.get(name, QColor(200, 200, 200))
                painter.setPen(QPen(color, 2))
                painter.drawLine(QPointF(x, 0), QPointF(x, height))
                painter.drawText(
                    QRectF(x + 3, 2, 120, 16), MARKER_LABELS.get(name, name)
                )
        painter.end()
