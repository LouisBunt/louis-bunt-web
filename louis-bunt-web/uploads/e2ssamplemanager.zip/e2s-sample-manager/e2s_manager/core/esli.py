"""Der Korg-'esli'-Chunk: alle Electribe-spezifischen Sample-Metadaten.

Binärlayout exakt wie in Oe2sSLE (e2s_sample_all.py, Copyright (C)
2015-2017 Jonathan Taquet, GPL-3) dokumentiert: 1172 Bytes mit festen
Offsets. Die Daten bleiben als bytearray erhalten (unbekannte Bytes
werden nie verändert), Zugriff erfolgt über typisierte Descriptor-
Properties statt der __getattr__-Magie des Originals.
"""

from __future__ import annotations

import struct

ESLI_SIZE = 1172
NUM_SLICES = 64
NUM_STEPS = 64

# Erwartete Werte der unbekannten Fix-Bytes (von der Electribe so geschrieben)
FIX_16_22 = b"\x00\x00\x00\x7f\x00\x01\x00\x00\x00\x00\x00\x00"
FIX_27 = b"\x00"
FIX_35_3C = b"\x00" * 7
FIX_43_48 = b"\x01\xb0\x04\x00\x00"
FIX_4C = b"\x00"


class OscCategory:
    ANALOG = 0
    AUDIO_IN = 1
    KICK = 2
    SNARE = 3
    CLAP = 4
    HIHAT = 5
    CYMBAL = 6
    HITS = 7
    SHOTS = 8
    VOICE = 9
    SE = 10
    FX = 11
    TOM = 12
    PERC = 13
    PHRASE = 14
    LOOP = 15
    PCM = 16
    USER = 17


OSC_CATEGORY_NAMES = {
    OscCategory.ANALOG: "Analog",
    OscCategory.AUDIO_IN: "Audio In",
    OscCategory.KICK: "Kick",
    OscCategory.SNARE: "Snare",
    OscCategory.CLAP: "Clap",
    OscCategory.HIHAT: "HiHat",
    OscCategory.CYMBAL: "Cymbal",
    OscCategory.HITS: "Hits",
    OscCategory.SHOTS: "Shots",
    OscCategory.VOICE: "Voice",
    OscCategory.SE: "SE",
    OscCategory.FX: "FX",
    OscCategory.TOM: "Tom",
    OscCategory.PERC: "Perc.",
    OscCategory.PHRASE: "Phrase",
    OscCategory.LOOP: "Loop",
    OscCategory.PCM: "PCM",
    OscCategory.USER: "User",
}

OSC_CATEGORY_IDS = {name: cat for cat, name in OSC_CATEGORY_NAMES.items()}

BEAT_NAMES = {0: "16", 1: "32", 2: "8 Tri", 3: "16 Tri"}
BEAT_IDS = {name: beat for beat, name in BEAT_NAMES.items()}

# Von der Electribe erlaubte Zeichen im Sample-Namen
NAME_ALLOWED_CHARS = (
    " !#$%&'()+,-.0123456789;=@"
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`"
    "abcdefghijklmnopqrstuvwxyz{}~"
)


def sanitize_name(name: str) -> str:
    """Auf 16 Zeichen kürzen und unzulässige Zeichen ersetzen."""
    cleaned = "".join(c if c in NAME_ALLOWED_CHARS else "_" for c in name)
    return cleaned[:16]


class _Field:
    """Descriptor für ein struct-Feld an festem Offset im rawdata-Puffer."""

    def __init__(self, offset: int, fmt: str):
        self.offset = offset
        self.fmt = fmt
        self.size = struct.calcsize(fmt)

    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        value = struct.unpack_from(self.fmt, obj.rawdata, self.offset)
        return value[0] if len(value) == 1 else value

    def __set__(self, obj, value):
        struct.pack_into(self.fmt, obj.rawdata, self.offset, value)


class Slice:
    """Sicht auf einen der 64 Slice-Einträge (4 × uint32 ab Offset 0x50)."""

    _BASE = 0x50
    _STRIDE = 16

    def __init__(self, esli: "Esli", index: int):
        self._esli = esli
        self._offset = self._BASE + index * self._STRIDE

    def _get(self, rel: int, fmt: str) -> int:
        return struct.unpack_from(fmt, self._esli.rawdata, self._offset + rel)[0]

    def _set(self, rel: int, fmt: str, value: int) -> None:
        struct.pack_into(fmt, self._esli.rawdata, self._offset + rel, value)

    @property
    def start(self) -> int:  # in Frames, signiert (Original nutzt '<i')
        return self._get(0, "<i")

    @start.setter
    def start(self, value: int) -> None:
        self._set(0, "<i", value)

    @property
    def length(self) -> int:
        return self._get(4, "<I")

    @length.setter
    def length(self, value: int) -> None:
        self._set(4, "<I", value)

    @property
    def attack_length(self) -> int:
        return self._get(8, "<I")

    @attack_length.setter
    def attack_length(self, value: int) -> None:
        self._set(8, "<I", value)

    @property
    def amplitude(self) -> int:
        return self._get(12, "<I")

    @amplitude.setter
    def amplitude(self, value: int) -> None:
        self._set(12, "<I", value)


class SliceSteps:
    """Sicht auf die 64 Step-Zuordnungen (signed byte, -1 = aus)."""

    _BASE = 0x450

    def __init__(self, esli: "Esli"):
        self._esli = esli

    def __getitem__(self, index: int) -> int:
        if not 0 <= index < NUM_STEPS:
            raise IndexError(index)
        return struct.unpack_from("b", self._esli.rawdata, self._BASE + index)[0]

    def __setitem__(self, index: int, value: int) -> None:
        if not 0 <= index < NUM_STEPS:
            raise IndexError(index)
        struct.pack_into("b", self._esli.rawdata, self._BASE + index, value)

    def __len__(self) -> int:
        return NUM_STEPS


class Esli:
    """Der 1172 Byte große esli-Chunk-Inhalt."""

    osc_0index = _Field(0x00, "<H")
    _name_raw = _Field(0x02, "16s")
    osc_category = _Field(0x12, "<H")
    osc_import_num = _Field(0x14, "<H")
    _fix_16_22 = _Field(0x16, "12s")
    play_log_period = _Field(0x22, "<H")
    play_volume = _Field(0x24, "<H")
    _var_26 = _Field(0x26, "1s")
    _fix_27 = _Field(0x27, "1s")
    start_point_address = _Field(0x28, "<I")  # in Bytes
    loop_start_offset = _Field(0x2C, "<I")  # in Bytes, relativ zum Start
    end_offset = _Field(0x30, "<I")  # in Bytes, relativ zum Start
    one_shot = _Field(0x34, "?")
    _fix_35_3c = _Field(0x35, "7s")
    wav_data_size = _Field(0x3C, "<I")
    use_chan0 = _Field(0x40, "B")
    use_chan1 = _Field(0x41, "?")  # True = stereo
    play_level_12db = _Field(0x42, "?")
    _fix_43_48 = _Field(0x43, "5s")
    sampling_freq = _Field(0x48, "<I")
    _fix_4c = _Field(0x4C, "1s")
    sample_tune = _Field(0x4D, "<b")
    osc_0index1 = _Field(0x4E, "<H")
    slicing_num_steps = _Field(0x490, "B")
    slicing_beat = _Field(0x491, "B")
    slices_num_active_steps = _Field(0x492, "B")

    def __init__(self, rawdata: bytes | None = None):
        if rawdata is not None:
            if len(rawdata) < ESLI_SIZE:
                raise ValueError(
                    f"esli-Chunk zu klein: {len(rawdata)} < {ESLI_SIZE} Bytes"
                )
            # Größere Chunks als 1172 Bytes akzeptieren (wie Original),
            # zusätzliche Bytes bleiben erhalten
            self.rawdata = bytearray(rawdata)
        else:
            self.rawdata = bytearray(ESLI_SIZE)
            self.reset()
        self.slices = [Slice(self, i) for i in range(NUM_SLICES)]
        self.slice_steps = SliceSteps(self)

    def reset(self) -> None:
        self._fix_16_22 = FIX_16_22
        self._fix_27 = FIX_27
        self._fix_35_3c = FIX_35_3C
        self._fix_43_48 = FIX_43_48
        self._fix_4c = FIX_4C
        self.use_chan0 = 1
        self.osc_category = OscCategory.USER
        self.one_shot = True

    def copy(self) -> "Esli":
        return Esli(bytes(self.rawdata))

    # --- Sample-Nummer (1-basiert wie am Gerät angezeigt) ---

    @property
    def osc_num(self) -> int:
        return self.osc_0index + 1

    @osc_num.setter
    def osc_num(self, num: int) -> None:
        self.osc_0index = num - 1
        self.osc_0index1 = num - 1

    # --- Name als Python-String ---

    @property
    def name(self) -> str:
        return self._name_raw.rstrip(b"\x00").decode("ascii", "replace")

    @name.setter
    def name(self, value: str) -> None:
        encoded = sanitize_name(value).encode("ascii", "replace")
        self._name_raw = encoded.ljust(16, b"\x00")

    # --- Abgeleitete Werte ---

    @property
    def category_name(self) -> str:
        return OSC_CATEGORY_NAMES.get(self.osc_category, f"?{self.osc_category}")

    @property
    def is_stereo(self) -> bool:
        return bool(self.use_chan1)

    def unusual_fix_fields(self) -> list[str]:
        """Abweichende Fix-Bytes melden (Diagnose, kein Fehler)."""
        issues = []
        for attr, expected in (
            ("_fix_16_22", FIX_16_22),
            ("_fix_27", FIX_27),
            ("_fix_35_3c", FIX_35_3C),
            ("_fix_43_48", FIX_43_48),
            ("_fix_4c", FIX_4C),
        ):
            if getattr(self, attr) != expected:
                issues.append(attr)
        if self.use_chan0 != 1:
            issues.append("use_chan0")
        return issues

    def payload(self) -> bytes:
        return bytes(self.rawdata)
