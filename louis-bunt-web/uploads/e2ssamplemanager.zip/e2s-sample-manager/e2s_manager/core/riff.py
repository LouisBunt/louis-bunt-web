"""RIFF/WAVE-Parser für e2sSample-Dateien.

Portiert aus Oe2sSLE (RIFF/__init__.py, RIFF/smpl.py, RIFF/cue.py,
Copyright (C) 2015-2017 Jonathan Taquet, GPL-3) und aufgeräumt:
unbekannte Chunks bleiben als Rohdaten erhalten, smpl/cue werden in
echte Python-Objekte geparst und beim Schreiben neu serialisiert.
"""

from __future__ import annotations

import struct
from dataclasses import dataclass
from typing import BinaryIO

HEADER_FMT = "<4sI"
HEADER_LEN = struct.calcsize(HEADER_FMT)

WAVE_FORMAT_PCM = 0x0001
WAVE_FORMAT_IEEE_FLOAT = 0x0003
WAVE_FORMAT_EXTENSIBLE = 0xFFFE


class RiffError(Exception):
    """Fehler beim Lesen/Schreiben einer RIFF-Datei."""


class TruncatedChunk(RiffError):
    """Chunk ist länger als die verbleibenden Daten."""


def read_header(file: BinaryIO) -> tuple[bytes, int]:
    raw = file.read(HEADER_LEN)
    if len(raw) != HEADER_LEN:
        raise TruncatedChunk("Chunk-Header unvollständig")
    chunk_id, size = struct.unpack(HEADER_FMT, raw)
    return chunk_id, size


def write_header(file: BinaryIO, chunk_id: bytes, size: int) -> None:
    file.write(struct.pack(HEADER_FMT, chunk_id, size))


class Chunk:
    """Basisklasse: ein Chunk mit id und serialisierbarem Inhalt."""

    id: bytes = b"    "

    def payload(self) -> bytes:
        raise NotImplementedError

    def write(self, file: BinaryIO) -> None:
        data = self.payload()
        write_header(file, self.id, len(data))
        file.write(data)
        if len(data) & 1:  # RIFF: Chunks sind auf 2 Bytes ausgerichtet
            file.write(b"\x00")

    def total_size(self) -> int:
        n = len(self.payload())
        return HEADER_LEN + n + (n & 1)


class RawChunk(Chunk):
    """Unbekannter Chunk: Rohdaten werden unverändert durchgereicht."""

    def __init__(self, chunk_id: bytes, rawdata: bytes = b""):
        self.id = chunk_id
        self.rawdata = bytearray(rawdata)

    def payload(self) -> bytes:
        return bytes(self.rawdata)


class FmtChunk(Chunk):
    """'fmt '-Chunk (nur PCM wird interpretiert, Rest bleibt roh)."""

    id = b"fmt "
    _COMMON_FMT = "<HHIIH"

    def __init__(
        self,
        format_tag: int = WAVE_FORMAT_PCM,
        channels: int = 1,
        samples_per_sec: int = 44100,
        avg_bytes_per_sec: int = 88200,
        block_align: int = 2,
        bit_per_sample: int = 16,
        extra_raw: bytes = b"",
    ):
        self.format_tag = format_tag
        self.channels = channels
        self.samples_per_sec = samples_per_sec
        self.avg_bytes_per_sec = avg_bytes_per_sec
        self.block_align = block_align
        self.bit_per_sample = bit_per_sample
        self.extra_raw = extra_raw

    @classmethod
    def parse(cls, raw: bytes) -> "FmtChunk":
        common_len = struct.calcsize(cls._COMMON_FMT)
        if len(raw) < common_len:
            raise RiffError("'fmt '-Chunk zu kurz")
        tag, chans, sps, abps, align = struct.unpack_from(cls._COMMON_FMT, raw)
        bit_per_sample = 0
        offset = common_len
        # bitPerSample folgt bei PCM, IEEE float und extensible direkt
        if len(raw) >= offset + 2:
            bit_per_sample = struct.unpack_from("<H", raw, offset)[0]
            offset += 2
        return cls(tag, chans, sps, abps, align, bit_per_sample, raw[offset:])

    def payload(self) -> bytes:
        return (
            struct.pack(
                self._COMMON_FMT,
                self.format_tag,
                self.channels,
                self.samples_per_sec,
                self.avg_bytes_per_sec,
                self.block_align,
            )
            + struct.pack("<H", self.bit_per_sample)
            + self.extra_raw
        )

    def strip_extra(self) -> None:
        """Zusatzfelder entfernen (Electribe erwartet reines PCM-fmt)."""
        self.extra_raw = b""

    def recompute_derived(self) -> None:
        self.block_align = self.channels * self.bit_per_sample // 8
        self.avg_bytes_per_sec = self.samples_per_sec * self.block_align


class DataChunk(Chunk):
    """'data'-Chunk: die Audio-Rohdaten."""

    id = b"data"

    def __init__(self, rawdata: bytes = b""):
        self.rawdata = bytearray(rawdata)

    def payload(self) -> bytes:
        return bytes(self.rawdata)


@dataclass
class SmplLoop:
    identifier: int = 0
    type: int = 0  # 0 = forward
    start: int = 0  # in Frames
    end: int = 0
    fraction: int = 0
    play_count: int = 0  # 0 = endlos

    _FMT = "<6I"

    def pack(self) -> bytes:
        return struct.pack(
            self._FMT, self.identifier, self.type, self.start,
            self.end, self.fraction, self.play_count,
        )


class SmplChunk(Chunk):
    """'smpl'-Chunk: Loop-Informationen für DAWs."""

    id = b"smpl"
    _HEAD_FMT = "<9I"

    def __init__(self):
        self.manufacturer = 0
        self.product = 0
        self.sample_period = 0
        self.midi_unity_note = 60
        self.midi_pitch_fraction = 0
        self.smpte_format = 0
        self.smpte_offset = 0
        self.loops: list[SmplLoop] = []
        self.additional_raw = b""

    @classmethod
    def parse(cls, raw: bytes) -> "SmplChunk":
        head_len = struct.calcsize(cls._HEAD_FMT)
        if len(raw) < head_len:
            raise RiffError("'smpl'-Chunk zu kurz")
        (man, prod, period, note, frac, smpte_fmt, smpte_off,
         num_loops, num_extra) = struct.unpack_from(cls._HEAD_FMT, raw)
        chunk = cls()
        chunk.manufacturer = man
        chunk.product = prod
        chunk.sample_period = period
        chunk.midi_unity_note = note
        chunk.midi_pitch_fraction = frac
        chunk.smpte_format = smpte_fmt
        chunk.smpte_offset = smpte_off
        offset = head_len
        loop_len = struct.calcsize(SmplLoop._FMT)
        for _ in range(num_loops):
            if offset + loop_len > len(raw):
                break  # abgeschnittene Loop-Liste tolerieren
            chunk.loops.append(SmplLoop(*struct.unpack_from(SmplLoop._FMT, raw, offset)))
            offset += loop_len
        chunk.additional_raw = raw[offset:offset + num_extra]
        return chunk

    def payload(self) -> bytes:
        return (
            struct.pack(
                self._HEAD_FMT,
                self.manufacturer, self.product, self.sample_period,
                self.midi_unity_note, self.midi_pitch_fraction,
                self.smpte_format, self.smpte_offset,
                len(self.loops), len(self.additional_raw),
            )
            + b"".join(loop.pack() for loop in self.loops)
            + self.additional_raw
        )


@dataclass
class CuePoint:
    identifier: int = 0
    position: int = 0
    fcc_chunk: bytes = b"data"
    chunk_start: int = 0
    block_start: int = 0
    sample_offset: int = 0

    _FMT = "<2I4s3I"

    def pack(self) -> bytes:
        return struct.pack(
            self._FMT, self.identifier, self.position, self.fcc_chunk,
            self.chunk_start, self.block_start, self.sample_offset,
        )


class CueChunk(Chunk):
    """'cue '-Chunk: Slice-/Markerpositionen für DAWs."""

    id = b"cue "

    def __init__(self):
        self.cue_points: list[CuePoint] = []

    @classmethod
    def parse(cls, raw: bytes) -> "CueChunk":
        if len(raw) < 4:
            raise RiffError("'cue '-Chunk zu kurz")
        num = struct.unpack_from("<I", raw)[0]
        chunk = cls()
        offset = 4
        point_len = struct.calcsize(CuePoint._FMT)
        for _ in range(num):
            if offset + point_len > len(raw):
                break
            chunk.cue_points.append(CuePoint(*struct.unpack_from(CuePoint._FMT, raw, offset)))
            offset += point_len
        return chunk

    def payload(self) -> bytes:
        return struct.pack("<I", len(self.cue_points)) + b"".join(
            p.pack() for p in self.cue_points
        )


def read_chunk_list(file: BinaryIO, total_size: int, factories: dict) -> list[Chunk]:
    """Liest Chunks bis total_size verbraucht ist.

    Defekte/abgeschnittene End-Chunks werden verworfen statt das
    komplette Laden scheitern zu lassen (wie im Original).
    """
    chunks: list[Chunk] = []
    remaining = total_size
    while remaining > 0:
        if remaining < HEADER_LEN:
            file.read(remaining)
            break
        chunk_id, size = read_header(file)
        remaining -= HEADER_LEN
        if size > remaining:
            file.read(remaining)
            break
        raw = file.read(size)
        if len(raw) != size:
            raise TruncatedChunk(f"Chunk {chunk_id!r} unvollständig")
        remaining -= size
        if size & 1 and remaining:  # Padding-Byte
            file.read(1)
            remaining -= 1
        factory = factories.get(chunk_id)
        if factory is not None:
            chunks.append(factory(raw))
        else:
            chunks.append(RawChunk(chunk_id, raw))
    return chunks
