"""WAV-Dateien in E2sSamples umwandeln (Port von e2s_sample_import.py).

Erweiterungen gegenüber dem Original:
- 32-bit-PCM und Float-WAVs werden ebenfalls konvertiert (via dsp)
- optionaler Auto-Trim von Stille direkt beim Import
"""

from __future__ import annotations

import os
from dataclasses import dataclass

from . import dsp, riff
from .esli import OSC_CATEGORY_IDS, OscCategory, sanitize_name
from .library import FIRST_USER_NUM
from .sample import E2sSample, play_log_period_for_freq

# Startwert für die Import-Nummern von User-Samples (wird beim Speichern
# der Library ohnehin neu vergeben, siehe library.save)
_import_counter = 550


@dataclass
class ImportOptions:
    osc_cat: str = "User"
    loop_type: int = 0  # 0 = One-Shot, 1 = Loop
    plus_12_db: bool = False
    force_osc_cat: bool = False
    force_loop_type: bool = False
    force_plus_12_db: bool = False
    smp_num_from: int = FIRST_USER_NUM
    force_mono: bool = False
    mono_mix: float = 0.0  # -1 = links ... +1 = rechts
    auto_trim_silence: bool = False
    trim_threshold_db: float = -60.0


@dataclass
class ImportResult:
    sample: E2sSample
    converted_from: str | None = None  # z.B. "24 bit", "float"
    converted_to_mono: bool = False
    trimmed_silence: bool = False


class ImportError_(Exception):
    pass


class EmptyWav(ImportError_):
    pass


class UnsupportedFormat(ImportError_):
    pass


def from_wav(filename: str, opts: ImportOptions | None = None) -> ImportResult:
    global _import_counter
    if opts is None:
        opts = ImportOptions()

    with open(filename, "rb") as f:
        sample = E2sSample(f)

    fmt = sample.fmt
    if not len(sample.data.rawdata):
        raise EmptyWav("Leere WAV-Dateien kann die Electribe nicht laden")

    # Auf 16-bit PCM bringen
    converted_from = None
    needs_convert = (
        fmt.format_tag != riff.WAVE_FORMAT_PCM or fmt.bit_per_sample != 16
    )
    if needs_convert:
        if fmt.format_tag == riff.WAVE_FORMAT_IEEE_FLOAT:
            converted_from = "float"
        else:
            converted_from = f"{fmt.bit_per_sample} bit"
        try:
            frames = dsp.convert_to_16bit_pcm(bytes(sample.data.rawdata), fmt)
        except ValueError as exc:
            raise UnsupportedFormat(str(exc)) from exc
        fmt.format_tag = riff.WAVE_FORMAT_PCM
        fmt.bit_per_sample = 16
        fmt.strip_extra()
        dsp.set_frames(sample, frames)

    result = ImportResult(sample, converted_from=converted_from)

    if not sample.has_korg():
        _init_esli_from_wav(sample, filename, opts)
        _import_counter += 1

    _apply_forced_options(sample, opts, result)

    if opts.auto_trim_silence:
        result.trimmed_silence = dsp.trim_silence(sample, opts.trim_threshold_db)

    return result


def _init_esli_from_wav(sample: E2sSample, filename: str, opts: ImportOptions) -> None:
    """esli-Chunk für ein frisch importiertes WAV anlegen (wie Original)."""
    esli = sample.esli  # legt korg/esli an
    fmt = sample.fmt
    data_len = len(sample.data.rawdata)

    esli.name = sanitize_name(os.path.splitext(os.path.basename(filename))[0])
    esli.sampling_freq = fmt.samples_per_sec
    esli.end_offset = esli.loop_start_offset = data_len - fmt.block_align
    esli.wav_data_size = data_len
    if fmt.channels > 1:
        esli.use_chan1 = True
    # volle Lautstärke (die Electribe selbst normalisiert beim Sampeln)
    esli.play_volume = 65535
    esli.osc_category = OSC_CATEGORY_IDS.get(opts.osc_cat, OscCategory.USER)
    esli.play_level_12db = bool(opts.plus_12_db)
    esli.osc_import_num = _import_counter
    esli.play_log_period = play_log_period_for_freq(fmt.samples_per_sec)

    # Loop-Punkt aus smpl-Chunk übernehmen
    smpl_used = False
    smpl = sample.smpl
    if smpl and smpl.loops:
        loop = smpl.loops[0]
        if loop.play_count != 1:
            start = loop.start * fmt.block_align
            end = loop.end * fmt.block_align
            if start < end and end <= data_len - fmt.block_align:
                esli.loop_start_offset = start - esli.start_point_address
                esli.one_shot = False
                esli.end_offset = end - esli.start_point_address
                smpl_used = True
    if not smpl_used and opts.loop_type == 1:
        esli.loop_start_offset = 0
        esli.one_shot = False

    # Slices aus cue-Punkten übernehmen
    cue = sample.cue
    if cue:
        num_frames = data_len // fmt.block_align
        start_frame = esli.start_point_address // fmt.block_align
        points = sorted(
            (p for p in cue.cue_points
             if p.fcc_chunk == b"data" and p.sample_offset < num_frames),
            key=lambda p: p.sample_offset,
        )
        for i, point in enumerate(points[:64]):
            esli.slices[i].start = point.sample_offset - start_frame
            esli.slices[i].length = num_frames - point.sample_offset
            if i > 0:
                esli.slices[i - 1].length = (
                    esli.slices[i].start - esli.slices[i - 1].start
                )


def _apply_forced_options(sample: E2sSample, opts: ImportOptions,
                          result: ImportResult) -> None:
    esli = sample.esli
    if opts.force_osc_cat:
        esli.osc_category = OSC_CATEGORY_IDS.get(opts.osc_cat, OscCategory.USER)
    if opts.force_loop_type:
        if opts.loop_type == 0:
            esli.loop_start_offset = esli.end_offset
            esli.one_shot = True
        else:
            esli.loop_start_offset = 0
            esli.one_shot = False
    if opts.force_plus_12_db:
        esli.play_level_12db = bool(opts.plus_12_db)
    if opts.force_mono:
        result.converted_to_mono = dsp.to_mono(sample, opts.mono_mix)
