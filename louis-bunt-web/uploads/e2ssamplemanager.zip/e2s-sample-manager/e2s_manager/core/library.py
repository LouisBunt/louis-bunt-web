"""Die e2sSample.all-Bibliothek: Header + bis zu 1020 Sample-Slots.

Dateiformat (aus Oe2sSLE e2s_sample_all.py):
- 16 Bytes Magic: b"e2s sample all\\x1A\\x00"
- 1020 × uint32-LE Dateioffsets (0 = leerer Slot), Slot i = Sample #(i+1)
- ab 0x1000: die RIFF/WAVE-Samples

Nummern-Regeln der Electribe (aus der Original-GUI):
- Nutzbare Sample-Nummern: 19-421 und 501-999
- Beim Speichern bekommt jedes Sample seine OSC_importNum aus der
  Factory-Tabelle (Nummern < 501) bzw. 550+Index (User-Bereich)
"""

from __future__ import annotations

import os
import struct
import tempfile
from typing import Iterator, Optional

from .sample import E2sSample

MAGIC = b"e2s sample all\x1a\x00"
NUM_SLOTS = 1020
DATA_START = 0x1000

# Maximale Summe der Audiodaten (Sample-RAM der Electribe)
MAX_WAV_DATA_SIZE = 26214396

# Am Gerät nutzbare Sample-Nummern (1-basiert)
FIRST_USER_NUM = 19
FORBIDDEN_RANGE = range(422, 501)
LAST_NUM = 999

FACTORY_IMPORT_NUMS = (
    list(range(50, 86)) + list(range(87, 113)) + list(range(114, 126))
    + list(range(127, 136)) + list(range(137, 182)) + [183, 185, 187, 188]
    + list(range(190, 461))
)


def is_valid_num(num: int) -> bool:
    return FIRST_USER_NUM <= num <= LAST_NUM and num not in FORBIDDEN_RANGE


def next_valid_num(num: int, direction: int = 1) -> Optional[int]:
    """Nächste gültige Nummer in der gegebenen Richtung, None am Ende."""
    num += direction
    if num in FORBIDDEN_RANGE:
        num = 501 if direction > 0 else 421
    if FIRST_USER_NUM <= num <= LAST_NUM:
        return num
    return None


class LibraryError(Exception):
    pass


class SlotInUse(LibraryError):
    pass


class NoFreeSlot(LibraryError):
    pass


class Library:
    """Geordnete Sammlung der Samples, sortiert nach Sample-Nummer."""

    def __init__(self):
        self.samples: list[E2sSample] = []
        self.load_errors: list[str] = []

    # --- Laden/Speichern ---

    @classmethod
    def load(cls, filename: str) -> "Library":
        lib = cls()
        with open(filename, "rb") as f:
            if f.read(len(MAGIC)) != MAGIC:
                raise LibraryError(
                    "Keine e2sSample.all-Datei (Magic-Header fehlt)"
                )
            offsets = struct.unpack(f"<{NUM_SLOTS}I", f.read(4 * NUM_SLOTS))
            for slot, offset in enumerate(offsets):
                if not offset:
                    continue
                try:
                    f.seek(offset)
                    lib.samples.append(E2sSample(f))
                except Exception as exc:  # defekten Slot überspringen
                    lib.load_errors.append(
                        f"Sample-Slot #{slot + 1} konnte nicht gelesen "
                        f"werden: {exc}"
                    )
        lib.sort()
        return lib

    def save(self, filename: str) -> None:
        """Atomar speichern: erst Temp-Datei, dann Umbenennen."""
        self.sort()
        # OSC_importNum wie die Electribe/das Original vergeben
        for sample in self.samples:
            esli = sample.esli
            if esli.osc_0index < 500:
                esli.osc_import_num = FACTORY_IMPORT_NUMS[esli.osc_0index - 18]
            else:
                esli.osc_import_num = 550 + esli.osc_0index - 500

        offsets = [0] * NUM_SLOTS
        cleaned = []
        next_addr = DATA_START
        for sample in self.samples:
            clean = sample.get_clean_copy()
            slot = clean.esli.osc_0index
            if offsets[slot]:
                raise LibraryError(
                    f"Mehrere Samples mit Nummer #{slot + 1} - "
                    "Speichern abgebrochen"
                )
            offsets[slot] = next_addr
            cleaned.append(clean)
            next_addr += clean.total_size()

        dirname = os.path.dirname(os.path.abspath(filename)) or "."
        fd, tmp_path = tempfile.mkstemp(
            dir=dirname, prefix=".e2s_tmp_", suffix=".all"
        )
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(MAGIC)
                f.write(struct.pack(f"<{NUM_SLOTS}I", *offsets))
                for clean in cleaned:
                    clean.write(f)
            os.replace(tmp_path, filename)
        except BaseException:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise

    # --- Verwaltung ---

    def sort(self) -> None:
        self.samples.sort(key=lambda s: s.esli.osc_0index)

    def __len__(self) -> int:
        return len(self.samples)

    def __iter__(self) -> Iterator[E2sSample]:
        return iter(self.samples)

    def used_nums(self) -> set[int]:
        return {s.esli.osc_num for s in self.samples}

    def get_by_num(self, num: int) -> Optional[E2sSample]:
        for sample in self.samples:
            if sample.esli.osc_num == num:
                return sample
        return None

    def first_free_num(self, start: int = FIRST_USER_NUM) -> int:
        used = self.used_nums()
        num: Optional[int] = start
        while num is not None:
            if is_valid_num(num) and num not in used:
                return num
            num = next_valid_num(num)
        raise NoFreeSlot("Kein freier Sample-Platz mehr")

    def add(self, sample: E2sSample, num: Optional[int] = None,
            search_from: int = FIRST_USER_NUM) -> int:
        """Sample einfügen. Ohne num wird der erste freie Platz genutzt."""
        if num is None:
            num = self.first_free_num(search_from)
        elif not is_valid_num(num):
            raise LibraryError(f"Ungültige Sample-Nummer #{num}")
        elif num in self.used_nums():
            raise SlotInUse(f"Sample-Nummer #{num} ist schon belegt")
        sample.esli.osc_num = num
        self.samples.append(sample)
        self.sort()
        return num

    def remove(self, sample: E2sSample) -> None:
        self.samples.remove(sample)

    def total_wav_size(self) -> int:
        return sum(s.esli.wav_data_size for s in self.samples)

    def exceeds_memory(self) -> bool:
        return self.total_wav_size() > MAX_WAV_DATA_SIZE
