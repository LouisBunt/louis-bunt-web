"""Samples als WAV-Dateien exportieren."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass

from .sample import E2sSample


@dataclass
class ExportOptions:
    with_smpl: bool = True  # Loop-Punkte als smpl-Chunk
    with_cue: bool = True  # Slices als cue-Punkte


def default_filename(sample: E2sSample) -> str:
    """Dateiname wie im Original: '042_Name.wav'."""
    esli = sample.esli
    safe = re.sub(r'[\\/:*?"<>|]', "_", esli.name).strip() or "sample"
    return f"{esli.osc_num:0>3}_{safe}.wav"


def export_sample(sample: E2sSample, filename: str,
                  opts: ExportOptions | None = None) -> None:
    if opts is None:
        opts = ExportOptions()
    with open(filename, "wb") as f:
        sample.export_wav(f, with_smpl=opts.with_smpl, with_cue=opts.with_cue)


def export_all(samples, directory: str,
               opts: ExportOptions | None = None) -> list[str]:
    """Alle Samples in ein Verzeichnis exportieren, gibt Dateinamen zurück."""
    written = []
    for sample in samples:
        path = os.path.join(directory, default_filename(sample))
        export_sample(sample, path, opts)
        written.append(path)
    return written
