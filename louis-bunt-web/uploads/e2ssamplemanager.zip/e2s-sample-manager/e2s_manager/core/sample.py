"""Ein einzelnes Sample: RIFF/WAVE-Datei mit Korg-'korg'/'esli'-Chunk."""

from __future__ import annotations

import io
import math
from typing import BinaryIO, Optional

from . import riff
from .esli import Esli


class KorgChunk(riff.Chunk):
    """'korg'-Container-Chunk; enthält den 'esli'-Chunk (und ggf. weitere)."""

    id = b"korg"

    def __init__(self, esli: Esli | None = None, extra_chunks: list[riff.Chunk] | None = None):
        self.esli = esli if esli is not None else Esli()
        self.extra_chunks = extra_chunks or []

    @classmethod
    def parse(cls, raw: bytes) -> "KorgChunk":
        subchunks = riff.read_chunk_list(io.BytesIO(raw), len(raw), {})
        esli = None
        extra = []
        for chunk in subchunks:
            if chunk.id == b"esli" and esli is None:
                esli = Esli(chunk.payload())
            else:
                extra.append(chunk)
        if esli is None:
            raise riff.RiffError("'korg'-Chunk ohne 'esli'-Chunk")
        return cls(esli, extra)

    def payload(self) -> bytes:
        buf = io.BytesIO()
        esli_raw = self.esli.payload()
        riff.write_header(buf, b"esli", len(esli_raw))
        buf.write(esli_raw)
        for chunk in self.extra_chunks:
            chunk.write(buf)
        return buf.getvalue()


_CHUNK_FACTORIES = {
    b"fmt ": riff.FmtChunk.parse,
    b"smpl": riff.SmplChunk.parse,
    b"cue ": riff.CueChunk.parse,
    b"korg": KorgChunk.parse,
    b"data": lambda raw: riff.DataChunk(raw),
}


def play_log_period_for_freq(freq: int) -> int:
    """Playback-Rate der Electribe aus der Samplerate (Formel aus Oe2sSLE)."""
    if freq == 0:
        return 65535
    return max(0, int(round(63132 - math.log2(freq) * 3072)))


class E2sSample:
    """Ein WAV mit Electribe-Metadaten, wie es in der e2sSample.all liegt."""

    def __init__(self, file: Optional[BinaryIO] = None):
        self.chunks: list[riff.Chunk] = []
        if file is not None:
            self.read(file)

    # --- Zugriff auf die wichtigen Chunks ---

    def _find(self, chunk_id: bytes):
        for chunk in self.chunks:
            if chunk.id == chunk_id:
                return chunk
        return None

    @property
    def fmt(self) -> riff.FmtChunk:
        chunk = self._find(b"fmt ")
        if chunk is None:
            raise riff.RiffError("Sample ohne 'fmt '-Chunk")
        return chunk

    @property
    def data(self) -> riff.DataChunk:
        chunk = self._find(b"data")
        if chunk is None:
            raise riff.RiffError("Sample ohne 'data'-Chunk")
        return chunk

    @property
    def korg(self) -> KorgChunk:
        chunk = self._find(b"korg")
        if chunk is None:
            chunk = KorgChunk()
            self.chunks.append(chunk)
        return chunk

    @property
    def esli(self) -> Esli:
        return self.korg.esli

    @property
    def smpl(self) -> Optional[riff.SmplChunk]:
        return self._find(b"smpl")

    @property
    def cue(self) -> Optional[riff.CueChunk]:
        return self._find(b"cue ")

    def has_korg(self) -> bool:
        return self._find(b"korg") is not None

    # --- Abgeleitete Eigenschaften ---

    @property
    def num_frames(self) -> int:
        align = self.fmt.block_align or 1
        return len(self.data.rawdata) // align

    @property
    def duration_seconds(self) -> float:
        freq = self.esli.sampling_freq or self.fmt.samples_per_sec
        return self.num_frames / freq if freq else 0.0

    # --- Lesen/Schreiben ---

    def read(self, file: BinaryIO) -> None:
        chunk_id, size = riff.read_header(file)
        if chunk_id != b"RIFF":
            raise riff.RiffError(f"'RIFF' erwartet, {chunk_id!r} gefunden")
        if size < 4:
            raise riff.RiffError("RIFF-Chunk zu klein")
        form_type = file.read(4)
        if form_type != b"WAVE":
            raise riff.RiffError(f"'WAVE' erwartet, {form_type!r} gefunden")
        self.chunks = riff.read_chunk_list(file, size - 4, _CHUNK_FACTORIES)
        if self._find(b"fmt ") is None or self._find(b"data") is None:
            raise riff.RiffError("WAV ohne fmt-/data-Chunk")

    def riff_size(self) -> int:
        return 4 + sum(chunk.total_size() for chunk in self.chunks)

    def total_size(self) -> int:
        return riff.HEADER_LEN + self.riff_size()

    def write(self, file: BinaryIO) -> None:
        riff.write_header(file, b"RIFF", self.riff_size())
        file.write(b"WAVE")
        for chunk in self.chunks:
            chunk.write(file)

    def to_bytes(self) -> bytes:
        buf = io.BytesIO()
        self.write(buf)
        return buf.getvalue()

    def get_clean_copy(self) -> "E2sSample":
        """Nur fmt/data/korg behalten - so schreibt es auch die Electribe.

        data und korg werden geteilt (keine Kopie der Audiodaten), fmt wird
        ohne Zusatzfelder neu aufgebaut - wie get_clean_copy() im Original.
        """
        copy = E2sSample()
        fmt = self.fmt
        clean_fmt = riff.FmtChunk(
            fmt.format_tag, fmt.channels, fmt.samples_per_sec,
            fmt.avg_bytes_per_sec, fmt.block_align, fmt.bit_per_sample,
        )
        copy.chunks = [clean_fmt, self.data, self.korg]
        return copy

    def deep_copy(self) -> "E2sSample":
        """Vollständige Kopie (für Undo-Snapshots)."""
        return E2sSample(io.BytesIO(self.to_bytes()))

    def export_wav(self, file: BinaryIO, with_smpl: bool = False, with_cue: bool = False) -> None:
        """Als WAV exportieren, optional mit smpl-Loop und cue-Slices."""
        sample = self.get_clean_copy()
        esli = sample.esli
        fmt = sample.fmt
        uid = 0

        if with_smpl and esli.loop_start_offset < esli.end_offset:
            smpl = riff.SmplChunk()
            freq = esli.sampling_freq or 1
            smpl.sample_period = int(round(1.0 / freq * 10**9))
            loop = riff.SmplLoop(
                identifier=uid,
                start=(esli.start_point_address + esli.loop_start_offset) // fmt.block_align,
                end=(esli.start_point_address + esli.end_offset) // fmt.block_align,
            )
            smpl.loops.append(loop)
            sample.chunks.append(smpl)
            uid += 1

        if with_cue:
            num_frames = sample.num_frames
            start_frame = esli.start_point_address // fmt.block_align
            seen_starts = set()
            cue = riff.CueChunk()
            for sl in esli.slices:
                if not sl.length or sl.start >= num_frames or sl.start in seen_starts:
                    continue
                seen_starts.add(sl.start)
                cue.cue_points.append(riff.CuePoint(
                    identifier=uid,
                    position=sl.start + start_frame,
                    fcc_chunk=b"data",
                    sample_offset=sl.start + start_frame,
                ))
                uid += 1
            if cue.cue_points:
                sample.chunks.append(cue)

        sample.write(file)
