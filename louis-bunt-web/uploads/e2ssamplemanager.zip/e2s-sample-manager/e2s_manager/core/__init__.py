"""Formats- und DSP-Kern ohne GUI-Abhängigkeiten."""

from .esli import Esli, OscCategory, OSC_CATEGORY_NAMES, OSC_CATEGORY_IDS
from .library import (
    Library, LibraryError, MAX_WAV_DATA_SIZE, is_valid_num, next_valid_num,
)
from .sample import E2sSample

__all__ = [
    "Esli", "OscCategory", "OSC_CATEGORY_NAMES", "OSC_CATEGORY_IDS",
    "Library", "LibraryError", "MAX_WAV_DATA_SIZE",
    "is_valid_num", "next_valid_num", "E2sSample",
]
