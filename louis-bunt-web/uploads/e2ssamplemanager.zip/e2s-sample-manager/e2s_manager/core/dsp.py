"""Audio-Verarbeitung auf numpy-Basis.

Alle Funktionen arbeiten auf E2sSample-Objekten (16-bit PCM) und halten
die esli-Metadaten (Punkte, Slices, Größen) konsistent - die Punktlogik
folgt e2s_sample_trim.py und e2s_sample_import.py aus Oe2sSLE.
"""

from __future__ import annotations

import numpy as np

from .sample import E2sSample
from . import riff


def get_frames(sample: E2sSample) -> np.ndarray:
    """Audiodaten als int16-Array der Form (frames, channels)."""
    fmt = sample.fmt
    data = np.frombuffer(bytes(sample.data.rawdata), dtype="<i2")
    channels = max(1, fmt.channels)
    usable = len(data) - len(data) % channels
    return data[:usable].reshape(-1, channels)


def set_frames(sample: E2sSample, frames: np.ndarray) -> None:
    """Audiodaten ersetzen und fmt/esli-Größen aktualisieren."""
    fmt = sample.fmt
    esli = sample.esli
    frames = np.ascontiguousarray(frames, dtype="<i2")
    fmt.channels = frames.shape[1]
    fmt.bit_per_sample = 16
    fmt.recompute_derived()
    sample.data.rawdata = bytearray(frames.tobytes())
    esli.wav_data_size = len(sample.data.rawdata)
    esli.use_chan1 = frames.shape[1] > 1


# --- Bittiefen-/Formatkonvertierung beim Import ---

def convert_to_16bit_pcm(raw: bytes, fmt: riff.FmtChunk) -> np.ndarray:
    """Beliebige WAV-PCM/Float-Daten in (frames, channels) int16 wandeln."""
    tag = fmt.format_tag
    bits = fmt.bit_per_sample
    if tag == riff.WAVE_FORMAT_EXTENSIBLE:
        # Sub-Format steckt in den ersten 2 Bytes der GUID (nach cbSize+validBits+mask)
        if len(fmt.extra_raw) >= 10:
            tag = int.from_bytes(fmt.extra_raw[8:10], "little")

    if tag == riff.WAVE_FORMAT_PCM:
        if bits == 8:
            data = np.frombuffer(raw, dtype=np.uint8).astype(np.int16)
            data = (data - 128) * 256
        elif bits == 16:
            data = np.frombuffer(raw, dtype="<i2").astype(np.int16)
        elif bits == 24:
            usable = len(raw) - len(raw) % 3
            as_bytes = np.frombuffer(raw[:usable], dtype=np.uint8).reshape(-1, 3)
            # obere 2 Bytes übernehmen (wie Oe2sSLE wav_pcm_24b_to_16b)
            data = as_bytes[:, 1:3].copy().view("<i2").reshape(-1)
        elif bits == 32:
            data = (np.frombuffer(raw, dtype="<i4") >> 16).astype(np.int16)
        else:
            raise ValueError(f"Nicht unterstützte PCM-Bittiefe: {bits}")
    elif tag == riff.WAVE_FORMAT_IEEE_FLOAT:
        dtype = "<f4" if bits == 32 else "<f8"
        floats = np.clip(np.frombuffer(raw, dtype=dtype), -1.0, 1.0)
        data = (floats * 32767.0).round().astype(np.int16)
    else:
        raise ValueError(f"Nicht unterstütztes WAV-Format (Tag 0x{tag:04X})")

    channels = max(1, fmt.channels)
    usable = len(data) - len(data) % channels
    return data[:usable].reshape(-1, channels)


# --- Stereo -> Mono ---

def mono_mix_weights(mix: float, channels: int) -> tuple[float, ...]:
    """Gewichte wie Oe2sSLE: mix -1.0 = links, 0.0 = Mitte, 1.0 = rechts."""
    w = ((1 - mix) / 2, 1 - (1 - mix) / 2) + (0.0,) * (channels - 2)
    total = sum(abs(x) for x in w) or 1.0
    return tuple(x / total for x in w)


def to_mono(sample: E2sSample, mix: float = 0.0) -> bool:
    """Stereo-Sample in Mono wandeln; Punkte/Größen werden angepasst."""
    fmt = sample.fmt
    if fmt.channels <= 1:
        return False
    channels = fmt.channels
    frames = get_frames(sample).astype(np.float64)
    weights = np.array(mono_mix_weights(mix, channels))
    mono = (frames @ weights).astype(np.int16).reshape(-1, 1)

    esli = sample.esli
    esli.start_point_address = esli.start_point_address // channels
    esli.loop_start_offset = esli.loop_start_offset // channels
    esli.end_offset = esli.end_offset // channels
    set_frames(sample, mono)
    return True


# --- Normalisieren ---

def normalize(sample: E2sSample, headroom_db: float = 0.0) -> bool:
    """Peak-Normalisierung. True, wenn sich etwas geändert hat."""
    frames = get_frames(sample)
    peak = int(np.max(np.abs(frames.astype(np.int32)))) if frames.size else 0
    if peak == 0:
        return False
    target = int(32767 * (10 ** (-abs(headroom_db) / 20)))
    if peak >= target:
        return False
    gain = target / peak
    boosted = np.clip(frames.astype(np.float64) * gain, -32768, 32767)
    set_frames(sample, boosted.astype(np.int16))
    return True


# --- Trim (Punkte-Logik aus e2s_sample_trim.py) ---

def trim(sample: E2sSample, start_frame: int, stop_frame: int) -> None:
    """Audio auf [start_frame, stop_frame] kürzen, Punkte/Slices anpassen."""
    fmt = sample.fmt
    esli = sample.esli
    frame_size = fmt.block_align
    num_frames = len(sample.data.rawdata) // frame_size

    start_frame = min(max(0, start_frame), num_frames - 1)
    stop_frame = min(max(0, stop_frame), num_frames - 1)
    start_frame, stop_frame = min(start_frame, stop_frame), max(start_frame, stop_frame)

    byte_offset = start_frame * frame_size
    esli.start_point_address = max(0, esli.start_point_address - byte_offset)
    for sl in esli.slices:
        sl.length = max(0, min(sl.length, sl.length + sl.start))
        sl.start = max(0, sl.start)

    new_frames = stop_frame - start_frame + 1
    byte_len = new_frames * frame_size

    esli.loop_start_offset = min(esli.loop_start_offset, byte_len - frame_size)
    esli.end_offset = min(esli.end_offset, byte_len - frame_size)
    for sl in esli.slices:
        if sl.start > new_frames - 1:
            sl.start = 0
            sl.length = 0
        else:
            sl.length = min(sl.length, new_frames - sl.start)

    sample.data.rawdata = sample.data.rawdata[byte_offset:byte_offset + byte_len]
    esli.wav_data_size = len(sample.data.rawdata)


# --- Auto-Trim von Stille (QoL, neu) ---

def find_silence_bounds(
    frames: np.ndarray, threshold_db: float = -60.0, window: int = 32
) -> tuple[int, int]:
    """(erster, letzter) Frame über der Schwelle; (0, n-1) wenn alles leise."""
    if frames.size == 0:
        return 0, 0
    level = np.max(np.abs(frames.astype(np.int32)), axis=1)
    threshold = int(32767 * (10 ** (threshold_db / 20)))
    loud = np.flatnonzero(level > threshold)
    if loud.size == 0:
        return 0, len(level) - 1
    first = max(0, int(loud[0]) - window)
    last = min(len(level) - 1, int(loud[-1]) + window)
    return first, last


def trim_silence(sample: E2sSample, threshold_db: float = -60.0) -> bool:
    """Stille am Anfang/Ende abschneiden. True, wenn gekürzt wurde."""
    frames = get_frames(sample)
    first, last = find_silence_bounds(frames, threshold_db)
    if first == 0 and last == len(frames) - 1:
        return False
    trim(sample, first, last)
    # Punkte auf den neuen Bereich setzen
    esli = sample.esli
    fmt = sample.fmt
    esli.start_point_address = 0
    esli.end_offset = len(sample.data.rawdata) - fmt.block_align
    if esli.one_shot or esli.loop_start_offset > esli.end_offset:
        esli.loop_start_offset = esli.end_offset
    return True


# --- Waveform-Peaks für die Anzeige ---

def peak_pyramid(frames: np.ndarray, base: int = 256) -> list[np.ndarray]:
    """Min/Max-Pyramide für schnelles Waveform-Zeichnen bei jedem Zoom."""
    if frames.size == 0:
        return []
    mono = frames.astype(np.int32)
    levels = []
    current_min = mono
    current_max = mono
    while len(current_min) > base:
        n = len(current_min) // 2 * 2
        current_min = np.minimum(current_min[:n:2], current_min[1:n:2])
        current_max = np.maximum(current_max[:n:2], current_max[1:n:2])
        levels.append((current_min, current_max))
    return levels
