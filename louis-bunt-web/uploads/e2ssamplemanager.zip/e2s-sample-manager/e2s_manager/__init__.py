"""E2S Sample Manager - Sample-Library-Editor für die Korg Electribe 2 Sampler.

Neuimplementierung von Oe2sSLE (Copyright (C) 2015-2018 Jonathan Taquet, GPL-3)
mit moderner Qt-Oberfläche, Undo/Redo, Auto-Backup und Batch-Werkzeugen.

Dieses Programm ist freie Software unter der GNU General Public License v3.
"""

__version__ = "0.1.0"
APP_NAME = "E2S Sample Manager"
