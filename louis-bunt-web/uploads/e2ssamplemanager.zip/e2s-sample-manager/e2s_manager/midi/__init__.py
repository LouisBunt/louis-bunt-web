"""Platzhalter für Phase 2: Hacktribe-MIDI/SysEx-Anbindung.

Geplant (auf Basis von hacktribe/scripts/e2sysex.py):
- Geräteerkennung per SysEx Search Device (42 50 00 00)
- Pattern-Backup/-Restore
- FX-/Groove-Import für Hacktribe-Firmware

Benötigt die optionalen Abhängigkeiten: pip install .[midi]
"""
