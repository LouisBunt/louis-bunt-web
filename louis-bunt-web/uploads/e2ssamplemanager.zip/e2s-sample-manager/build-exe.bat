@echo off
rem ============================================================
rem  E2S Sample Manager - Windows-Exe bauen (PyInstaller)
rem  Doppelklicken, warten, fertig: dist\E2S-Sample-Manager.exe
rem  Die Exe ist danach eigenstaendig (kein Python noetig).
rem  Voraussetzung: Python 3.10+ von https://python.org
rem ============================================================
cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
    echo Python wurde nicht gefunden!
    echo Bitte von https://www.python.org/downloads/ installieren
    echo und dabei "Add python.exe to PATH" anhaken.
    pause
    exit /b 1
)

echo [1/3] Build-Umgebung vorbereiten ...
py -3 -m venv .venv-build || (pause & exit /b 1)
".venv-build\Scripts\python.exe" -m pip install --upgrade pip

echo [2/3] Abhaengigkeiten installieren ...
".venv-build\Scripts\python.exe" -m pip install PySide6-Essentials numpy sounddevice psutil pyinstaller || (pause & exit /b 1)

echo [3/3] Exe bauen (dauert einige Minuten) ...
".venv-build\Scripts\pyinstaller.exe" --noconfirm --clean --onefile --windowed ^
    --name "E2S-Sample-Manager" run_app.py || (pause & exit /b 1)

echo.
echo ============================================================
echo  Fertig! Die Exe liegt hier:  dist\E2S-Sample-Manager.exe
echo  Du kannst sie ueberallhin kopieren, z.B. auf den Desktop.
echo ============================================================
pause
